package com.google.p010ar.core;

import android.hardware.camera2.CameraDevice;
import android.os.Handler;

/* renamed from: com.google.ar.core.an */
/* compiled from: SharedCamera */
final class C0034an extends CameraDevice.StateCallback {

    /* renamed from: d */
    public static final /* synthetic */ int f87d = 0;

    /* renamed from: a */
    final /* synthetic */ Handler f88a;

    /* renamed from: b */
    final /* synthetic */ CameraDevice.StateCallback f89b;

    /* renamed from: c */
    final /* synthetic */ SharedCamera f90c;

    C0034an(SharedCamera sharedCamera, Handler handler, CameraDevice.StateCallback stateCallback) {
        this.f90c = sharedCamera;
        this.f88a = handler;
        this.f89b = stateCallback;
    }

    public final void onClosed(CameraDevice cameraDevice) {
        this.f88a.post(new C0030aj(this.f89b, cameraDevice));
        this.f90c.onDeviceClosed(cameraDevice);
    }

    public final void onDisconnected(CameraDevice cameraDevice) {
        this.f88a.post(new C0032al(this.f89b, cameraDevice));
        this.f90c.onDeviceDisconnected(cameraDevice);
    }

    public final void onError(CameraDevice cameraDevice, int i) {
        this.f88a.post(new C0033am(this.f89b, cameraDevice, i));
        this.f90c.close();
    }

    public final void onOpened(CameraDevice cameraDevice) {
        this.f90c.sharedCameraInfo.mo335b(cameraDevice);
        this.f88a.post(new C0031ak(this.f89b, cameraDevice));
        this.f90c.onDeviceOpened(cameraDevice);
        this.f90c.sharedCameraInfo.mo338e(this.f90c.getGpuSurfaceTexture());
        this.f90c.sharedCameraInfo.mo340g(this.f90c.getGpuSurface());
    }
}
