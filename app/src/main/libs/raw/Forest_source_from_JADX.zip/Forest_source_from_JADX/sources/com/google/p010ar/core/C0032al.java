package com.google.p010ar.core;

import android.hardware.camera2.CameraDevice;

/* renamed from: com.google.ar.core.al */
final /* synthetic */ class C0032al implements Runnable {

    /* renamed from: a */
    private final CameraDevice.StateCallback f82a;

    /* renamed from: b */
    private final CameraDevice f83b;

    C0032al(CameraDevice.StateCallback stateCallback, CameraDevice cameraDevice) {
        this.f82a = stateCallback;
        this.f83b = cameraDevice;
    }

    public final void run() {
        CameraDevice.StateCallback stateCallback = this.f82a;
        CameraDevice cameraDevice = this.f83b;
        int i = C0034an.f87d;
        stateCallback.onDisconnected(cameraDevice);
    }
}
