package com.google.p010ar.core;

import android.util.Log;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.google.ar.core.ad */
/* compiled from: InstallServiceImpl */
final class C0024ad implements Runnable {

    /* renamed from: a */
    final /* synthetic */ AtomicBoolean f28a;

    /* renamed from: b */
    final /* synthetic */ C0025ae f29b;

    C0024ad(C0025ae aeVar, AtomicBoolean atomicBoolean) {
        this.f29b = aeVar;
        this.f28a = atomicBoolean;
    }

    public final void run() {
        if (!this.f28a.getAndSet(true)) {
            Log.w("ARCore-InstallService", "requestInstall timed out, launching fullscreen.");
            C0025ae aeVar = this.f29b;
            C0063w.m74o(aeVar.f30a, aeVar.f31b);
        }
    }
}
