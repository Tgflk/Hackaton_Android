package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.NotYetAvailableException */
public class NotYetAvailableException extends Exception {
    public NotYetAvailableException() {
    }

    public NotYetAvailableException(String str) {
        super(str);
    }
}
