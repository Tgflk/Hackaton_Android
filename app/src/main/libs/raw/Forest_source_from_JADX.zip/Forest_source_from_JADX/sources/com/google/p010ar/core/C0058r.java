package com.google.p010ar.core;

import android.view.View;

/* renamed from: com.google.ar.core.r */
/* compiled from: InstallActivity */
final class C0058r implements View.OnClickListener {

    /* renamed from: a */
    final /* synthetic */ InstallActivity f131a;

    C0058r(InstallActivity installActivity) {
        this.f131a = installActivity;
    }

    public final void onClick(View view) {
        this.f131a.animateToSpinner();
        this.f131a.startInstaller();
    }
}
