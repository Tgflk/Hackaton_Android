package com.google.p010ar.core;

import android.content.pm.PackageInstaller;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.ar.core.aa */
/* compiled from: InstallServiceImpl */
final class C0021aa extends PackageInstaller.SessionCallback {

    /* renamed from: a */
    final Map<Integer, PackageInstaller.SessionInfo> f22a = new HashMap();

    /* renamed from: b */
    final /* synthetic */ C0061u f23b;

    /* renamed from: c */
    final /* synthetic */ C0063w f24c;

    C0021aa(C0063w wVar, C0061u uVar) {
        this.f24c = wVar;
        this.f23b = uVar;
    }

    public final void onActiveChanged(int i, boolean z) {
    }

    public final void onBadgingChanged(int i) {
    }

    public final void onCreated(int i) {
        this.f22a.put(Integer.valueOf(i), this.f24c.f149g.getSessionInfo(i));
    }

    public final void onFinished(int i, boolean z) {
        PackageInstaller.SessionInfo remove = this.f22a.remove(Integer.valueOf(i));
        if (remove != null && "com.google.ar.core".equals(remove.getAppPackageName())) {
            Log.i("ARCore-InstallService", "Detected ARCore install completion");
            this.f23b.mo354a(C0062v.COMPLETED);
        }
    }

    public final void onProgressChanged(int i, float f) {
    }
}
