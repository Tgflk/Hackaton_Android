package com.google.p010ar.core;

import android.view.View;
import com.google.p010ar.core.exceptions.UnavailableUserDeclinedInstallationException;

/* renamed from: com.google.ar.core.q */
/* compiled from: InstallActivity */
final class C0057q implements View.OnClickListener {

    /* renamed from: a */
    final /* synthetic */ InstallActivity f130a;

    C0057q(InstallActivity installActivity) {
        this.f130a = installActivity;
    }

    public final void onClick(View view) {
        this.f130a.finishWithFailure(new UnavailableUserDeclinedInstallationException());
    }
}
