package com.google.p004a.p006b.p007a.p008a.p009a;

import android.os.IBinder;
import android.os.IInterface;
import com.google.p004a.p005a.C0007b;

/* renamed from: com.google.a.b.a.a.a.b */
/* compiled from: IInstallService */
public abstract class C0010b extends C0007b implements C0011c {
    /* renamed from: b */
    public static C0011c m11b(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.play.core.install.protocol.IInstallService");
        if (queryLocalInterface instanceof C0011c) {
            return (C0011c) queryLocalInterface;
        }
        return new C0009a(iBinder);
    }
}
