package org.fmod;

import android.media.AudioRecord;
import android.util.Log;
import java.nio.ByteBuffer;

/* renamed from: org.fmod.a */
final class C0162a implements Runnable {

    /* renamed from: a */
    private final FMODAudioDevice f460a;

    /* renamed from: b */
    private final ByteBuffer f461b;

    /* renamed from: c */
    private final int f462c;

    /* renamed from: d */
    private final int f463d;

    /* renamed from: e */
    private final int f464e = 2;

    /* renamed from: f */
    private volatile Thread f465f;

    /* renamed from: g */
    private volatile boolean f466g;

    /* renamed from: h */
    private AudioRecord f467h;

    /* renamed from: i */
    private boolean f468i;

    C0162a(FMODAudioDevice fMODAudioDevice, int i, int i2) {
        this.f460a = fMODAudioDevice;
        this.f462c = i;
        this.f463d = i2;
        this.f461b = ByteBuffer.allocateDirect(AudioRecord.getMinBufferSize(i, i2, 2));
    }

    /* renamed from: d */
    private void m265d() {
        AudioRecord audioRecord = this.f467h;
        if (audioRecord != null) {
            if (audioRecord.getState() == 1) {
                this.f467h.stop();
            }
            this.f467h.release();
            this.f467h = null;
        }
        this.f461b.position(0);
        this.f468i = false;
    }

    /* renamed from: a */
    public final int mo685a() {
        return this.f461b.capacity();
    }

    /* renamed from: b */
    public final void mo686b() {
        if (this.f465f != null) {
            mo687c();
        }
        this.f466g = true;
        this.f465f = new Thread(this);
        this.f465f.start();
    }

    /* renamed from: c */
    public final void mo687c() {
        while (this.f465f != null) {
            this.f466g = false;
            try {
                this.f465f.join();
                this.f465f = null;
            } catch (InterruptedException unused) {
            }
        }
    }

    public final void run() {
        int i = 3;
        while (this.f466g) {
            if (!this.f468i && i > 0) {
                m265d();
                AudioRecord audioRecord = new AudioRecord(1, this.f462c, this.f463d, this.f464e, this.f461b.capacity());
                this.f467h = audioRecord;
                int state = audioRecord.getState();
                boolean z = true;
                if (state != 1) {
                    z = false;
                }
                this.f468i = z;
                if (z) {
                    this.f461b.position(0);
                    this.f467h.startRecording();
                    i = 3;
                } else {
                    Log.e("FMOD", "AudioRecord failed to initialize (status " + this.f467h.getState() + ")");
                    i += -1;
                    m265d();
                }
            }
            if (this.f468i && this.f467h.getRecordingState() == 3) {
                AudioRecord audioRecord2 = this.f467h;
                ByteBuffer byteBuffer = this.f461b;
                this.f460a.fmodProcessMicData(this.f461b, audioRecord2.read(byteBuffer, byteBuffer.capacity()));
                this.f461b.position(0);
            }
        }
        m265d();
    }
}
