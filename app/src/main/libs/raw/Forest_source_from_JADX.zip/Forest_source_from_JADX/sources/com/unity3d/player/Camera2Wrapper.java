package com.unity3d.player;

import android.content.Context;
import android.graphics.Rect;
import android.hardware.Camera;

public class Camera2Wrapper implements C0135e {

    /* renamed from: a */
    private Context f165a;

    /* renamed from: b */
    private C0127c f166b = null;

    /* renamed from: c */
    private final int f167c = 100;

    public Camera2Wrapper(Context context) {
        this.f165a = context;
        initCamera2Jni();
    }

    /* renamed from: a */
    private static int m88a(float f) {
        return (int) Math.min(Math.max((f * 2000.0f) - 0.0040893555f, -900.0f), 900.0f);
    }

    private final native void deinitCamera2Jni();

    private final native void initCamera2Jni();

    private final native void nativeFrameReady(Object obj, Object obj2, Object obj3, int i, int i2, int i3);

    private final native void nativeSurfaceTextureReady(Object obj);

    /* renamed from: a */
    public final void mo375a() {
        deinitCamera2Jni();
        closeCamera2();
    }

    /* renamed from: a */
    public final void mo376a(Object obj) {
        nativeSurfaceTextureReady(obj);
    }

    /* renamed from: a */
    public final void mo377a(Object obj, Object obj2, Object obj3, int i, int i2, int i3) {
        nativeFrameReady(obj, obj2, obj3, i, i2, i3);
    }

    /* access modifiers changed from: protected */
    public void closeCamera2() {
        C0127c cVar = this.f166b;
        if (cVar != null) {
            cVar.mo570b();
        }
        this.f166b = null;
    }

    /* access modifiers changed from: protected */
    public int getCamera2Count() {
        if (PlatformSupport.LOLLIPOP_SUPPORT) {
            return C0127c.m156a(this.f165a);
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    public int getCamera2FocalLengthEquivalent(int i) {
        if (PlatformSupport.LOLLIPOP_SUPPORT) {
            return C0127c.m177d(this.f165a, i);
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    public int[] getCamera2Resolutions(int i) {
        if (PlatformSupport.LOLLIPOP_SUPPORT) {
            return C0127c.m180e(this.f165a, i);
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public int getCamera2SensorOrientation(int i) {
        if (PlatformSupport.LOLLIPOP_SUPPORT) {
            return C0127c.m157a(this.f165a, i);
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    public Object getCameraFocusArea(float f, float f2) {
        int a = m88a(f);
        int a2 = m88a(1.0f - f2);
        return new Camera.Area(new Rect(a - 100, a2 - 100, a + 100, a2 + 100), 1000);
    }

    /* access modifiers changed from: protected */
    public Rect getFrameSizeCamera2() {
        C0127c cVar = this.f166b;
        return cVar != null ? cVar.mo567a() : new Rect();
    }

    /* access modifiers changed from: protected */
    public boolean initializeCamera2(int i, int i2, int i3, int i4, int i5) {
        if (!PlatformSupport.LOLLIPOP_SUPPORT || this.f166b != null || UnityPlayer.currentActivity == null) {
            return false;
        }
        C0127c cVar = new C0127c(this);
        this.f166b = cVar;
        return cVar.mo569a(this.f165a, i, i2, i3, i4, i5);
    }

    /* access modifiers changed from: protected */
    public boolean isCamera2AutoFocusPointSupported(int i) {
        if (PlatformSupport.LOLLIPOP_SUPPORT) {
            return C0127c.m175c(this.f165a, i);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public boolean isCamera2FrontFacing(int i) {
        if (PlatformSupport.LOLLIPOP_SUPPORT) {
            return C0127c.m173b(this.f165a, i);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void pauseCamera2() {
        C0127c cVar = this.f166b;
        if (cVar != null) {
            cVar.mo572d();
        }
    }

    /* access modifiers changed from: protected */
    public boolean setAutoFocusPoint(float f, float f2) {
        C0127c cVar;
        if (!PlatformSupport.LOLLIPOP_SUPPORT || (cVar = this.f166b) == null) {
            return false;
        }
        return cVar.mo568a(f, f2);
    }

    /* access modifiers changed from: protected */
    public void startCamera2() {
        C0127c cVar = this.f166b;
        if (cVar != null) {
            cVar.mo571c();
        }
    }

    /* access modifiers changed from: protected */
    public void stopCamera2() {
        C0127c cVar = this.f166b;
        if (cVar != null) {
            cVar.mo573e();
        }
    }
}
