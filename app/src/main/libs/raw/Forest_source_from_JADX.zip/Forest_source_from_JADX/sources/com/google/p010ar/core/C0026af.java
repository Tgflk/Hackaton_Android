package com.google.p010ar.core;

/* renamed from: com.google.ar.core.af */
/* compiled from: InstallServiceImpl */
final class C0026af extends Exception {
    C0026af() {
        super("InstallService not bound");
    }
}
