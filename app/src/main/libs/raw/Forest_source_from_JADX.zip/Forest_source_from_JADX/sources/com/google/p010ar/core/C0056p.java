package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: com.google.ar.core.p */
/* compiled from: InstallActivity */
final class C0056p implements C0049i {

    /* renamed from: a */
    final /* synthetic */ AtomicReference f129a;

    C0056p(AtomicReference atomicReference) {
        this.f129a = atomicReference;
    }

    /* renamed from: a */
    public final void mo341a(ArCoreApk.Availability availability) {
        this.f129a.set(availability);
    }
}
