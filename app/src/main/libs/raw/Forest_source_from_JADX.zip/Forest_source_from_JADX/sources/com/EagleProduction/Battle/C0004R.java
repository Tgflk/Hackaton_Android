package com.EagleProduction.Battle;

/* renamed from: com.EagleProduction.Battle.R */
public final class C0004R {

    /* renamed from: com.EagleProduction.Battle.R$id */
    public static final class C0005id {
        public static final int __arcore_cancelButton = 2130771968;
        public static final int __arcore_continueButton = 2130771969;
        public static final int __arcore_messageText = 2130771970;
        public static final int unitySurfaceView = 2130771971;

        private C0005id() {
        }
    }

    /* renamed from: com.EagleProduction.Battle.R$layout */
    public static final class layout {
        public static final int __arcore_education = 2130837504;

        private layout() {
        }
    }

    /* renamed from: com.EagleProduction.Battle.R$mipmap */
    public static final class mipmap {
        public static final int app_icon = 2130903040;
        public static final int app_icon_round = 2130903041;
        public static final int ic_launcher_background = 2130903042;
        public static final int ic_launcher_foreground = 2130903043;

        private mipmap() {
        }
    }

    /* renamed from: com.EagleProduction.Battle.R$raw */
    public static final class raw {
        public static final int keep_arcore = 2130968576;

        private raw() {
        }
    }

    /* renamed from: com.EagleProduction.Battle.R$string */
    public static final class string {
        public static final int __arcore_cancel = 2131034112;
        public static final int __arcore_continue = 2131034113;
        public static final int __arcore_install_app = 2131034114;
        public static final int __arcore_install_feature = 2131034115;
        public static final int __arcore_installing = 2131034116;
        public static final int app_name = 2131034117;
        public static final int game_view_content_description = 2131034118;

        private string() {
        }
    }

    /* renamed from: com.EagleProduction.Battle.R$style */
    public static final class style {
        public static final int BaseUnityTheme = 2131099648;
        public static final int UnityThemeSelector = 2131099649;
        public static final int UnityThemeSelector_Translucent = 2131099650;

        private style() {
        }
    }

    private C0004R() {
    }
}
