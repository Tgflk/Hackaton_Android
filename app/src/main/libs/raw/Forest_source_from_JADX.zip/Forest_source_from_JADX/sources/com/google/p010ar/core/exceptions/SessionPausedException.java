package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.SessionPausedException */
public class SessionPausedException extends IllegalStateException {
    public SessionPausedException() {
    }

    public SessionPausedException(String str) {
        super(str);
    }
}
