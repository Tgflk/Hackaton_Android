package com.google.p010ar.core;

import java.util.LinkedHashMap;
import java.util.Map;

/* renamed from: com.google.ar.core.m */
/* compiled from: FaceCache */
final class C0053m extends LinkedHashMap<Long, AugmentedFace> {
    C0053m() {
        super(1, 0.75f, true);
    }

    /* access modifiers changed from: protected */
    public final boolean removeEldestEntry(Map.Entry<Long, AugmentedFace> entry) {
        return size() > 10;
    }
}
