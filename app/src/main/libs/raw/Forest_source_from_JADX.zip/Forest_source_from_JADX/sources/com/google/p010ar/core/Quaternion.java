package com.google.p010ar.core;

/* renamed from: com.google.ar.core.Quaternion */
class Quaternion {

    /* renamed from: a */
    public static final Quaternion f16a = new Quaternion();

    /* renamed from: w */
    private float f17w = 1.0f;

    /* renamed from: x */
    private float f18x = 0.0f;

    /* renamed from: y */
    private float f19y = 0.0f;

    /* renamed from: z */
    private float f20z = 0.0f;

    public Quaternion() {
        mo239a(0.0f, 0.0f, 0.0f, 1.0f);
    }

    /* renamed from: i */
    public static Quaternion m25i(Quaternion quaternion, Quaternion quaternion2, float f) {
        float f2;
        Quaternion quaternion3 = new Quaternion();
        float f3 = (quaternion.f18x * quaternion2.f18x) + (quaternion.f19y * quaternion2.f19y) + (quaternion.f20z * quaternion2.f20z) + (quaternion.f17w * quaternion2.f17w);
        if (f3 < 0.0f) {
            Quaternion quaternion4 = new Quaternion(quaternion2);
            f3 = -f3;
            quaternion4.f18x = -quaternion4.f18x;
            quaternion4.f19y = -quaternion4.f19y;
            quaternion4.f20z = -quaternion4.f20z;
            quaternion4.f17w = -quaternion4.f17w;
            quaternion2 = quaternion4;
        }
        float acos = (float) Math.acos((double) f3);
        float sqrt = (float) Math.sqrt((double) (1.0f - (f3 * f3)));
        if (((double) Math.abs(sqrt)) > 0.001d) {
            float f4 = 1.0f / sqrt;
            f2 = ((float) Math.sin((double) ((1.0f - f) * acos))) * f4;
            f = ((float) Math.sin((double) (f * acos))) * f4;
        } else {
            f2 = 1.0f - f;
        }
        float f5 = (quaternion.f18x * f2) + (quaternion2.f18x * f);
        quaternion3.f18x = f5;
        float f6 = (quaternion.f19y * f2) + (quaternion2.f19y * f);
        quaternion3.f19y = f6;
        float f7 = (quaternion.f20z * f2) + (quaternion2.f20z * f);
        quaternion3.f20z = f7;
        float f8 = (f2 * quaternion.f17w) + (f * quaternion2.f17w);
        quaternion3.f17w = f8;
        float sqrt2 = (float) (1.0d / Math.sqrt((double) ((((f5 * f5) + (f6 * f6)) + (f7 * f7)) + (f8 * f8))));
        quaternion3.f18x *= sqrt2;
        quaternion3.f19y *= sqrt2;
        quaternion3.f20z *= sqrt2;
        quaternion3.f17w *= sqrt2;
        return quaternion3;
    }

    /* renamed from: j */
    public static void m26j(Quaternion quaternion, float[] fArr, int i, float[] fArr2, int i2) {
        float f = fArr[i];
        float f2 = fArr[i + 1];
        float f3 = fArr[i + 2];
        float f4 = quaternion.f18x;
        float f5 = quaternion.f19y;
        float f6 = quaternion.f20z;
        float f7 = quaternion.f17w;
        float f8 = ((f7 * f) + (f5 * f3)) - (f6 * f2);
        float f9 = ((f7 * f2) + (f6 * f)) - (f4 * f3);
        float f10 = ((f7 * f3) + (f4 * f2)) - (f5 * f);
        float f11 = -f4;
        float f12 = ((f * f11) - (f2 * f5)) - (f3 * f6);
        float f13 = -f6;
        float f14 = -f5;
        fArr2[i2] = (((f8 * f7) + (f12 * f11)) + (f9 * f13)) - (f10 * f14);
        fArr2[i2 + 1] = (((f9 * f7) + (f12 * f14)) + (f10 * f11)) - (f8 * f13);
        fArr2[i2 + 2] = (((f10 * f7) + (f12 * f13)) + (f8 * f14)) - (f9 * f11);
    }

    /* renamed from: a */
    public final void mo239a(float f, float f2, float f3, float f4) {
        this.f18x = f;
        this.f19y = f2;
        this.f20z = f3;
        this.f17w = f4;
    }

    /* renamed from: b */
    public final float mo240b() {
        return this.f18x;
    }

    /* renamed from: c */
    public final float mo241c() {
        return this.f19y;
    }

    /* renamed from: d */
    public final float mo242d() {
        return this.f20z;
    }

    /* renamed from: e */
    public final float mo243e() {
        return this.f17w;
    }

    /* renamed from: f */
    public final void mo244f(float[] fArr, int i) {
        fArr[i] = this.f18x;
        fArr[i + 1] = this.f19y;
        fArr[i + 2] = this.f20z;
        fArr[i + 3] = this.f17w;
    }

    /* renamed from: g */
    public final Quaternion mo245g() {
        return new Quaternion(-this.f18x, -this.f19y, -this.f20z, this.f17w);
    }

    /* renamed from: h */
    public final Quaternion mo246h(Quaternion quaternion) {
        Quaternion quaternion2 = new Quaternion();
        float f = this.f18x;
        float f2 = quaternion.f17w;
        float f3 = this.f19y;
        float f4 = quaternion.f20z;
        float f5 = this.f20z;
        float f6 = quaternion.f19y;
        float f7 = this.f17w;
        quaternion2.f18x = (((f * f2) + (f3 * f4)) - (f5 * f6)) + (quaternion.f18x * f7);
        float f8 = this.f18x;
        float f9 = -f8;
        float f10 = quaternion.f18x;
        quaternion2.f19y = (f9 * f4) + (f3 * f2) + (f5 * f10) + (f6 * f7);
        float f11 = quaternion.f19y;
        float f12 = this.f19y;
        quaternion2.f20z = ((f8 * f11) - (f12 * f10)) + (f5 * f2) + (f4 * f7);
        quaternion2.f17w = (((f9 * f10) - (f12 * f11)) - (this.f20z * quaternion.f20z)) + (f7 * f2);
        return quaternion2;
    }

    /* renamed from: k */
    public final void mo247k(float[] fArr, int i) {
        float f = this.f18x;
        float f2 = this.f19y;
        float f3 = this.f20z;
        float f4 = this.f17w;
        float f5 = (f * f) + (f2 * f2) + (f3 * f3) + (f4 * f4);
        float f6 = 0.0f;
        if (f5 > 0.0f) {
            f6 = 2.0f / f5;
        }
        float f7 = f * f6;
        float f8 = f2 * f6;
        float f9 = f6 * f3;
        float f10 = f4 * f7;
        float f11 = f4 * f8;
        float f12 = f4 * f9;
        float f13 = f7 * f;
        float f14 = f * f8;
        float f15 = f * f9;
        float f16 = f8 * f2;
        float f17 = f2 * f9;
        float f18 = f3 * f9;
        fArr[i] = 1.0f - (f16 + f18);
        fArr[i + 4] = f14 - f12;
        fArr[i + 8] = f15 + f11;
        fArr[i + 1] = f14 + f12;
        fArr[i + 5] = 1.0f - (f18 + f13);
        fArr[i + 9] = f17 - f10;
        fArr[i + 2] = f15 - f11;
        fArr[i + 6] = f17 + f10;
        fArr[i + 10] = 1.0f - (f13 + f16);
    }

    public final String toString() {
        return String.format("[%.3f, %.3f, %.3f, %.3f]", new Object[]{Float.valueOf(this.f18x), Float.valueOf(this.f19y), Float.valueOf(this.f20z), Float.valueOf(this.f17w)});
    }

    public Quaternion(float f, float f2, float f3, float f4) {
        mo239a(f, f2, f3, f4);
    }

    public Quaternion(Quaternion quaternion) {
        mo239a(quaternion.f18x, quaternion.f19y, quaternion.f20z, quaternion.f17w);
    }
}
