package com.google.p010ar.core;

import android.animation.ValueAnimator;

/* renamed from: com.google.ar.core.s */
/* compiled from: InstallActivity */
final class C0059s implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a */
    final /* synthetic */ int f132a;

    /* renamed from: b */
    final /* synthetic */ int f133b;

    /* renamed from: c */
    final /* synthetic */ int f134c;

    /* renamed from: d */
    final /* synthetic */ InstallActivity f135d;

    C0059s(InstallActivity installActivity, int i, int i2, int i3) {
        this.f135d = installActivity;
        this.f132a = i;
        this.f133b = i2;
        this.f134c = i3;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        float animatedFraction = 1.0f - valueAnimator.getAnimatedFraction();
        float animatedFraction2 = valueAnimator.getAnimatedFraction();
        int i = this.f132a;
        float f = ((float) this.f133b) * animatedFraction2;
        this.f135d.getWindow().setLayout((int) ((((float) i) * animatedFraction) + f), (int) ((((float) this.f134c) * animatedFraction) + f));
        this.f135d.getWindow().getDecorView().refreshDrawableState();
    }
}
