package com.google.p010ar.core;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import com.google.p004a.p006b.p007a.p008a.p009a.C0012d;
import com.google.p010ar.core.exceptions.FatalException;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.google.ar.core.ac */
/* compiled from: InstallServiceImpl */
final class C0023ac extends C0012d {

    /* renamed from: a */
    final /* synthetic */ AtomicBoolean f26a;

    /* renamed from: b */
    final /* synthetic */ C0025ae f27b;

    C0023ac(C0025ae aeVar, AtomicBoolean atomicBoolean) {
        this.f27b = aeVar;
        this.f26a = atomicBoolean;
    }

    /* renamed from: b */
    public final void mo13b(Bundle bundle) throws RemoteException {
        if (!this.f26a.getAndSet(true)) {
            int i = bundle.getInt("error.code", -100);
            int i2 = bundle.getInt("install.status", 0);
            if (i2 == 4) {
                this.f27b.f31b.mo354a(C0062v.COMPLETED);
            } else if (i != 0) {
                StringBuilder sb = new StringBuilder(51);
                sb.append("requestInstall = ");
                sb.append(i);
                sb.append(", launching fullscreen.");
                Log.w("ARCore-InstallService", sb.toString());
                C0025ae aeVar = this.f27b;
                C0063w.m74o(aeVar.f30a, aeVar.f31b);
            } else if (bundle.containsKey("resolution.intent")) {
                C0025ae aeVar2 = this.f27b;
                C0063w.m75p(aeVar2.f30a, bundle, aeVar2.f31b);
            } else if (i2 != 10) {
                switch (i2) {
                    case 1:
                    case 2:
                    case 3:
                        this.f27b.f31b.mo354a(C0062v.ACCEPTED);
                        return;
                    case 4:
                        this.f27b.f31b.mo354a(C0062v.COMPLETED);
                        return;
                    case 5:
                        this.f27b.f31b.mo355b(new FatalException("Unexpected FAILED install status without error."));
                        return;
                    case 6:
                        this.f27b.f31b.mo354a(C0062v.CANCELLED);
                        return;
                    default:
                        C0061u uVar = this.f27b.f31b;
                        StringBuilder sb2 = new StringBuilder(38);
                        sb2.append("Unexpected install status: ");
                        sb2.append(i2);
                        uVar.mo355b(new FatalException(sb2.toString()));
                        return;
                }
            } else {
                this.f27b.f31b.mo355b(new FatalException("Unexpected REQUIRES_UI_INTENT install status without an intent."));
            }
        }
    }

    /* renamed from: c */
    public final void mo14c(Bundle bundle) throws RemoteException {
    }
}
