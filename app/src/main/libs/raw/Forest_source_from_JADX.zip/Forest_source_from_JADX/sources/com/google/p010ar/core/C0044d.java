package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* 'enum' modifier removed */
/* renamed from: com.google.ar.core.d */
/* compiled from: ArCoreApk */
final class C0044d extends ArCoreApk.Availability {
    C0044d() {
        super("UNKNOWN_TIMED_OUT", 2, 2, (C0020a) null);
    }

    public final boolean isUnknown() {
        return true;
    }
}
