package com.unity3d.player;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Range;
import android.util.Size;
import android.util.SizeF;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/* renamed from: com.unity3d.player.c */
public final class C0127c {

    /* renamed from: b */
    private static CameraManager f319b;

    /* renamed from: c */
    private static String[] f320c;
    /* access modifiers changed from: private */

    /* renamed from: e */
    public static Semaphore f321e = new Semaphore(1);

    /* renamed from: A */
    private CameraCaptureSession.CaptureCallback f322A = new CameraCaptureSession.CaptureCallback() {
        public final void onCaptureCompleted(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, TotalCaptureResult totalCaptureResult) {
            C0127c.this.m167a(captureRequest.getTag());
        }

        public final void onCaptureFailed(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, CaptureFailure captureFailure) {
            C0136f.Log(5, "Camera2: Capture session failed " + captureRequest.getTag() + " reason " + captureFailure.getReason());
            C0127c.this.m167a(captureRequest.getTag());
        }

        public final void onCaptureSequenceAborted(CameraCaptureSession cameraCaptureSession, int i) {
        }

        public final void onCaptureSequenceCompleted(CameraCaptureSession cameraCaptureSession, int i, long j) {
        }
    };

    /* renamed from: B */
    private final CameraDevice.StateCallback f323B = new CameraDevice.StateCallback() {
        public final void onClosed(CameraDevice cameraDevice) {
            C0127c.f321e.release();
        }

        public final void onDisconnected(CameraDevice cameraDevice) {
            C0136f.Log(5, "Camera2: CameraDevice disconnected.");
            C0127c.this.m165a(cameraDevice);
            C0127c.f321e.release();
        }

        public final void onError(CameraDevice cameraDevice, int i) {
            C0136f.Log(6, "Camera2: Error opeining CameraDevice " + i);
            C0127c.this.m165a(cameraDevice);
            C0127c.f321e.release();
        }

        public final void onOpened(CameraDevice cameraDevice) {
            CameraDevice unused = C0127c.this.f327d = cameraDevice;
            C0127c.f321e.release();
        }
    };

    /* renamed from: C */
    private final ImageReader.OnImageAvailableListener f324C = new ImageReader.OnImageAvailableListener() {
        public final void onImageAvailable(ImageReader imageReader) {
            if (C0127c.f321e.tryAcquire()) {
                Image acquireNextImage = imageReader.acquireNextImage();
                if (acquireNextImage != null) {
                    Image.Plane[] planes = acquireNextImage.getPlanes();
                    if (acquireNextImage.getFormat() == 35 && planes != null && planes.length == 3) {
                        C0135e h = C0127c.this.f326a;
                        ByteBuffer buffer = planes[0].getBuffer();
                        ByteBuffer buffer2 = planes[1].getBuffer();
                        ByteBuffer buffer3 = planes[2].getBuffer();
                        h.mo377a(buffer, buffer2, buffer3, planes[0].getRowStride(), planes[1].getRowStride(), planes[1].getPixelStride());
                    } else {
                        C0136f.Log(6, "Camera2: Wrong image format.");
                    }
                    if (C0127c.this.f341s != null) {
                        C0127c.this.f341s.close();
                    }
                    Image unused = C0127c.this.f341s = acquireNextImage;
                }
                C0127c.f321e.release();
            }
        }
    };

    /* renamed from: D */
    private final SurfaceTexture.OnFrameAvailableListener f325D = new SurfaceTexture.OnFrameAvailableListener() {
        public final void onFrameAvailable(SurfaceTexture surfaceTexture) {
            C0127c.this.f326a.mo376a(surfaceTexture);
        }
    };
    /* access modifiers changed from: private */

    /* renamed from: a */
    public C0135e f326a = null;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public CameraDevice f327d;

    /* renamed from: f */
    private HandlerThread f328f;

    /* renamed from: g */
    private Handler f329g;

    /* renamed from: h */
    private Rect f330h;

    /* renamed from: i */
    private Rect f331i;

    /* renamed from: j */
    private int f332j;

    /* renamed from: k */
    private int f333k;

    /* renamed from: l */
    private float f334l = -1.0f;

    /* renamed from: m */
    private float f335m = -1.0f;

    /* renamed from: n */
    private int f336n;

    /* renamed from: o */
    private int f337o;

    /* renamed from: p */
    private boolean f338p = false;
    /* access modifiers changed from: private */

    /* renamed from: q */
    public Range f339q;
    /* access modifiers changed from: private */

    /* renamed from: r */
    public ImageReader f340r = null;
    /* access modifiers changed from: private */

    /* renamed from: s */
    public Image f341s;
    /* access modifiers changed from: private */

    /* renamed from: t */
    public CaptureRequest.Builder f342t;
    /* access modifiers changed from: private */

    /* renamed from: u */
    public CameraCaptureSession f343u = null;
    /* access modifiers changed from: private */

    /* renamed from: v */
    public Object f344v = new Object();

    /* renamed from: w */
    private int f345w;

    /* renamed from: x */
    private SurfaceTexture f346x;
    /* access modifiers changed from: private */

    /* renamed from: y */
    public Surface f347y = null;

    /* renamed from: z */
    private int f348z = C0133a.f356c;

    /* renamed from: com.unity3d.player.c$a */
    private enum C0133a {
        ;

        static {
            f357d = new int[]{1, 2, 3};
        }
    }

    protected C0127c(C0135e eVar) {
        this.f326a = eVar;
        m183g();
    }

    /* renamed from: a */
    public static int m156a(Context context) {
        return m176c(context).length;
    }

    /* renamed from: a */
    public static int m157a(Context context, int i) {
        try {
            return ((Integer) m169b(context).getCameraCharacteristics(m176c(context)[i]).get(CameraCharacteristics.SENSOR_ORIENTATION)).intValue();
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
            return 0;
        }
    }

    /* renamed from: a */
    private static int m158a(Range[] rangeArr, int i) {
        int i2 = -1;
        double d = Double.MAX_VALUE;
        for (int i3 = 0; i3 < rangeArr.length; i3++) {
            int intValue = ((Integer) rangeArr[i3].getLower()).intValue();
            int intValue2 = ((Integer) rangeArr[i3].getUpper()).intValue();
            float f = (float) i;
            if (f + 0.1f > ((float) intValue) && f - 0.1f < ((float) intValue2)) {
                return i;
            }
            double min = (double) ((float) Math.min(Math.abs(i - intValue), Math.abs(i - intValue2)));
            if (min < d) {
                i2 = i3;
                d = min;
            }
        }
        return ((Integer) (i > ((Integer) rangeArr[i2].getUpper()).intValue() ? rangeArr[i2].getUpper() : rangeArr[i2].getLower())).intValue();
    }

    /* renamed from: a */
    private static Rect m159a(Size[] sizeArr, double d, double d2) {
        Size[] sizeArr2 = sizeArr;
        double d3 = Double.MAX_VALUE;
        int i = 0;
        int i2 = 0;
        for (int i3 = 0; i3 < sizeArr2.length; i3++) {
            int width = sizeArr2[i3].getWidth();
            int height = sizeArr2[i3].getHeight();
            double abs = Math.abs(Math.log(d / ((double) width))) + Math.abs(Math.log(d2 / ((double) height)));
            if (abs < d3) {
                i = width;
                i2 = height;
                d3 = abs;
            }
        }
        return new Rect(0, 0, i, i2);
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m165a(CameraDevice cameraDevice) {
        synchronized (this.f344v) {
            this.f343u = null;
        }
        cameraDevice.close();
        this.f327d = null;
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m167a(Object obj) {
        if (obj == "Focus") {
            this.f338p = false;
            synchronized (this.f344v) {
                if (this.f343u != null) {
                    try {
                        this.f342t.set(CaptureRequest.CONTROL_AF_TRIGGER, 0);
                        this.f342t.setTag("Regular");
                        this.f343u.setRepeatingRequest(this.f342t.build(), this.f322A, this.f329g);
                    } catch (CameraAccessException e) {
                        C0136f.Log(6, "Camera2: CameraAccessException " + e);
                    }
                }
            }
        } else if (obj == "Cancel focus") {
            synchronized (this.f344v) {
                if (this.f343u != null) {
                    m189j();
                }
            }
        }
    }

    /* renamed from: a */
    private static Size[] m168a(CameraCharacteristics cameraCharacteristics) {
        StreamConfigurationMap streamConfigurationMap = (StreamConfigurationMap) cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (streamConfigurationMap == null) {
            C0136f.Log(6, "Camera2: configuration map is not available.");
            return null;
        }
        Size[] outputSizes = streamConfigurationMap.getOutputSizes(35);
        if (outputSizes == null || outputSizes.length == 0) {
            return null;
        }
        return outputSizes;
    }

    /* renamed from: b */
    private static CameraManager m169b(Context context) {
        if (f319b == null) {
            f319b = (CameraManager) context.getSystemService("camera");
        }
        return f319b;
    }

    /* renamed from: b */
    private void m171b(CameraCharacteristics cameraCharacteristics) {
        int intValue = ((Integer) cameraCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)).intValue();
        this.f333k = intValue;
        if (intValue > 0) {
            Rect rect = (Rect) cameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            this.f331i = rect;
            float width = ((float) rect.width()) / ((float) this.f331i.height());
            float width2 = ((float) this.f330h.width()) / ((float) this.f330h.height());
            if (width2 > width) {
                this.f336n = 0;
                this.f337o = (int) ((((float) this.f331i.height()) - (((float) this.f331i.width()) / width2)) / 2.0f);
            } else {
                this.f337o = 0;
                this.f336n = (int) ((((float) this.f331i.width()) - (((float) this.f331i.height()) * width2)) / 2.0f);
            }
            this.f332j = Math.min(this.f331i.width(), this.f331i.height()) / 20;
        }
    }

    /* renamed from: b */
    public static boolean m173b(Context context, int i) {
        try {
            return ((Integer) m169b(context).getCameraCharacteristics(m176c(context)[i]).get(CameraCharacteristics.LENS_FACING)).intValue() == 0;
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
            return false;
        }
    }

    /* renamed from: c */
    public static boolean m175c(Context context, int i) {
        try {
            return ((Integer) m169b(context).getCameraCharacteristics(m176c(context)[i]).get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)).intValue() > 0;
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
            return false;
        }
    }

    /* renamed from: c */
    private static String[] m176c(Context context) {
        if (f320c == null) {
            try {
                f320c = m169b(context).getCameraIdList();
            } catch (CameraAccessException e) {
                C0136f.Log(6, "Camera2: CameraAccessException " + e);
                f320c = new String[0];
            }
        }
        return f320c;
    }

    /* renamed from: d */
    public static int m177d(Context context, int i) {
        try {
            CameraCharacteristics cameraCharacteristics = m169b(context).getCameraCharacteristics(m176c(context)[i]);
            float[] fArr = (float[]) cameraCharacteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            SizeF sizeF = (SizeF) cameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (fArr.length > 0) {
                return (int) ((fArr[0] * 36.0f) / sizeF.getWidth());
            }
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
        }
        return 0;
    }

    /* renamed from: e */
    public static int[] m180e(Context context, int i) {
        try {
            Size[] a = m168a(m169b(context).getCameraCharacteristics(m176c(context)[i]));
            if (a == null) {
                return null;
            }
            int[] iArr = new int[(a.length * 2)];
            for (int i2 = 0; i2 < a.length; i2++) {
                int i3 = i2 * 2;
                iArr[i3] = a[i2].getWidth();
                iArr[i3 + 1] = a[i2].getHeight();
            }
            return iArr;
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
            return null;
        }
    }

    /* renamed from: g */
    private void m183g() {
        HandlerThread handlerThread = new HandlerThread("CameraBackground");
        this.f328f = handlerThread;
        handlerThread.start();
        this.f329g = new Handler(this.f328f.getLooper());
    }

    /* renamed from: h */
    private void m186h() {
        this.f328f.quit();
        try {
            this.f328f.join(4000);
            this.f328f = null;
            this.f329g = null;
        } catch (InterruptedException e) {
            this.f328f.interrupt();
            C0136f.Log(6, "Camera2: Interrupted while waiting for the background thread to finish " + e);
        }
    }

    /* renamed from: i */
    private void m188i() {
        try {
            if (!f321e.tryAcquire(4, TimeUnit.SECONDS)) {
                C0136f.Log(5, "Camera2: Timeout waiting to lock camera for closing.");
                return;
            }
            this.f327d.close();
            try {
                if (!f321e.tryAcquire(4, TimeUnit.SECONDS)) {
                    C0136f.Log(5, "Camera2: Timeout waiting to close camera.");
                }
            } catch (InterruptedException e) {
                C0136f.Log(6, "Camera2: Interrupted while waiting to close camera " + e);
            }
            this.f327d = null;
            f321e.release();
        } catch (InterruptedException e2) {
            C0136f.Log(6, "Camera2: Interrupted while trying to lock camera for closing " + e2);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: j */
    public void m189j() {
        try {
            if (this.f333k != 0 && this.f334l >= 0.0f && this.f334l <= 1.0f && this.f335m >= 0.0f) {
                if (this.f335m <= 1.0f) {
                    this.f338p = true;
                    int max = Math.max(this.f332j + 1, Math.min((int) ((((float) (this.f331i.width() - (this.f336n * 2))) * this.f334l) + ((float) this.f336n)), (this.f331i.width() - this.f332j) - 1));
                    int max2 = Math.max(this.f332j + 1, Math.min((int) ((((double) (this.f331i.height() - (this.f337o * 2))) * (1.0d - ((double) this.f335m))) + ((double) this.f337o)), (this.f331i.height() - this.f332j) - 1));
                    this.f342t.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[]{new MeteringRectangle(max - this.f332j, max2 - this.f332j, this.f332j * 2, this.f332j * 2, 999)});
                    this.f342t.set(CaptureRequest.CONTROL_AF_MODE, 1);
                    this.f342t.set(CaptureRequest.CONTROL_AF_TRIGGER, 1);
                    this.f342t.setTag("Focus");
                    this.f343u.capture(this.f342t.build(), this.f322A, this.f329g);
                    return;
                }
            }
            this.f342t.set(CaptureRequest.CONTROL_AF_MODE, 4);
            this.f342t.setTag("Regular");
            if (this.f343u != null) {
                this.f343u.setRepeatingRequest(this.f342t.build(), this.f322A, this.f329g);
            }
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
        }
    }

    /* renamed from: k */
    private void m190k() {
        try {
            if (this.f343u != null) {
                this.f343u.stopRepeating();
                this.f342t.set(CaptureRequest.CONTROL_AF_TRIGGER, 2);
                this.f342t.set(CaptureRequest.CONTROL_AF_MODE, 0);
                this.f342t.setTag("Cancel focus");
                this.f343u.capture(this.f342t.build(), this.f322A, this.f329g);
            }
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
        }
    }

    /* renamed from: a */
    public final Rect mo567a() {
        return this.f330h;
    }

    /* renamed from: a */
    public final boolean mo568a(float f, float f2) {
        if (this.f333k <= 0) {
            return false;
        }
        if (!this.f338p) {
            this.f334l = f;
            this.f335m = f2;
            synchronized (this.f344v) {
                if (!(this.f343u == null || this.f348z == C0133a.f355b)) {
                    m190k();
                }
            }
            return true;
        }
        C0136f.Log(5, "Camera2: Setting manual focus point already started.");
        return false;
    }

    /* renamed from: a */
    public final boolean mo569a(Context context, int i, int i2, int i3, int i4, int i5) {
        try {
            CameraCharacteristics cameraCharacteristics = f319b.getCameraCharacteristics(m176c(context)[i]);
            if (((Integer) cameraCharacteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)).intValue() == 2) {
                C0136f.Log(5, "Camera2: only LEGACY hardware level is supported.");
                return false;
            }
            Size[] a = m168a(cameraCharacteristics);
            if (!(a == null || a.length == 0)) {
                this.f330h = m159a(a, (double) i2, (double) i3);
                Range[] rangeArr = (Range[]) cameraCharacteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
                if (rangeArr == null || rangeArr.length == 0) {
                    C0136f.Log(6, "Camera2: target FPS ranges are not avialable.");
                } else {
                    int a2 = m158a(rangeArr, i4);
                    this.f339q = new Range(Integer.valueOf(a2), Integer.valueOf(a2));
                    try {
                        if (!f321e.tryAcquire(4, TimeUnit.SECONDS)) {
                            C0136f.Log(5, "Camera2: Timeout waiting to lock camera for opening.");
                            return false;
                        }
                        try {
                            f319b.openCamera(m176c(context)[i], this.f323B, this.f329g);
                            try {
                                if (!f321e.tryAcquire(4, TimeUnit.SECONDS)) {
                                    C0136f.Log(5, "Camera2: Timeout waiting to open camera.");
                                    return false;
                                }
                                f321e.release();
                                this.f345w = i5;
                                m171b(cameraCharacteristics);
                                return this.f327d != null;
                            } catch (InterruptedException e) {
                                C0136f.Log(6, "Camera2: Interrupted while waiting to open camera " + e);
                            }
                        } catch (CameraAccessException e2) {
                            C0136f.Log(6, "Camera2: CameraAccessException " + e2);
                            f321e.release();
                            return false;
                        }
                    } catch (InterruptedException e3) {
                        C0136f.Log(6, "Camera2: Interrupted while trying to lock camera for opening " + e3);
                        return false;
                    }
                }
            }
            return false;
        } catch (CameraAccessException e4) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e4);
            return false;
        }
    }

    /* renamed from: b */
    public final void mo570b() {
        if (this.f327d != null) {
            mo573e();
            m188i();
            this.f322A = null;
            this.f347y = null;
            this.f346x = null;
            Image image = this.f341s;
            if (image != null) {
                image.close();
                this.f341s = null;
            }
            ImageReader imageReader = this.f340r;
            if (imageReader != null) {
                imageReader.close();
                this.f340r = null;
            }
        }
        m186h();
    }

    /* renamed from: c */
    public final void mo571c() {
        List list;
        if (this.f340r == null) {
            ImageReader newInstance = ImageReader.newInstance(this.f330h.width(), this.f330h.height(), 35, 2);
            this.f340r = newInstance;
            newInstance.setOnImageAvailableListener(this.f324C, this.f329g);
            this.f341s = null;
            if (this.f345w != 0) {
                SurfaceTexture surfaceTexture = new SurfaceTexture(this.f345w);
                this.f346x = surfaceTexture;
                surfaceTexture.setDefaultBufferSize(this.f330h.width(), this.f330h.height());
                this.f346x.setOnFrameAvailableListener(this.f325D, this.f329g);
                this.f347y = new Surface(this.f346x);
            }
        }
        try {
            if (this.f343u == null) {
                CameraDevice cameraDevice = this.f327d;
                if (this.f347y != null) {
                    list = Arrays.asList(new Surface[]{this.f347y, this.f340r.getSurface()});
                } else {
                    list = Arrays.asList(new Surface[]{this.f340r.getSurface()});
                }
                cameraDevice.createCaptureSession(list, new CameraCaptureSession.StateCallback() {
                    public final void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
                        C0136f.Log(6, "Camera2: CaptureSession configuration failed.");
                    }

                    public final void onConfigured(CameraCaptureSession cameraCaptureSession) {
                        if (C0127c.this.f327d != null) {
                            synchronized (C0127c.this.f344v) {
                                CameraCaptureSession unused = C0127c.this.f343u = cameraCaptureSession;
                                try {
                                    CaptureRequest.Builder unused2 = C0127c.this.f342t = C0127c.this.f327d.createCaptureRequest(1);
                                    if (C0127c.this.f347y != null) {
                                        C0127c.this.f342t.addTarget(C0127c.this.f347y);
                                    }
                                    C0127c.this.f342t.addTarget(C0127c.this.f340r.getSurface());
                                    C0127c.this.f342t.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, C0127c.this.f339q);
                                    C0127c.this.m189j();
                                } catch (CameraAccessException e) {
                                    C0136f.Log(6, "Camera2: CameraAccessException " + e);
                                }
                            }
                        }
                    }
                }, this.f329g);
            } else if (this.f348z == C0133a.f355b) {
                this.f343u.setRepeatingRequest(this.f342t.build(), this.f322A, this.f329g);
            }
            this.f348z = C0133a.f354a;
        } catch (CameraAccessException e) {
            C0136f.Log(6, "Camera2: CameraAccessException " + e);
        }
    }

    /* renamed from: d */
    public final void mo572d() {
        synchronized (this.f344v) {
            if (this.f343u != null) {
                try {
                    this.f343u.stopRepeating();
                    this.f348z = C0133a.f355b;
                } catch (CameraAccessException e) {
                    C0136f.Log(6, "Camera2: CameraAccessException " + e);
                }
            }
        }
    }

    /* renamed from: e */
    public final void mo573e() {
        synchronized (this.f344v) {
            if (this.f343u != null) {
                try {
                    this.f343u.abortCaptures();
                } catch (CameraAccessException e) {
                    C0136f.Log(6, "Camera2: CameraAccessException " + e);
                }
                this.f343u.close();
                this.f343u = null;
                this.f348z = C0133a.f356c;
            }
        }
    }
}
