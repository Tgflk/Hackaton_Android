package com.google.p004a.p006b.p007a.p008a.p009a;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.p004a.p005a.C0006a;
import com.google.p004a.p005a.C0008c;
import java.util.List;

/* renamed from: com.google.a.b.a.a.a.a */
/* compiled from: IInstallService */
public final class C0009a extends C0006a implements C0011c {
    C0009a(IBinder iBinder) {
        super(iBinder, "com.google.android.play.core.install.protocol.IInstallService");
    }

    /* renamed from: d */
    public final void mo11d(String str, List<Bundle> list, Bundle bundle, C0013e eVar) throws RemoteException {
        Parcel a = mo4a();
        a.writeString(str);
        a.writeTypedList(list);
        C0008c.m7b(a, bundle);
        C0008c.m8c(a, eVar);
        mo7c(1, a);
    }

    /* renamed from: e */
    public final void mo12e(String str, Bundle bundle, C0013e eVar) throws RemoteException {
        Parcel a = mo4a();
        a.writeString(str);
        C0008c.m7b(a, bundle);
        C0008c.m8c(a, eVar);
        mo7c(2, a);
    }
}
