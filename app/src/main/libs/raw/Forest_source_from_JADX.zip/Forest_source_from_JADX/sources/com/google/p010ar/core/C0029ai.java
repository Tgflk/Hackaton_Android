package com.google.p010ar.core;

import android.media.ImageReader;

/* renamed from: com.google.ar.core.ai */
final /* synthetic */ class C0029ai implements ImageReader.OnImageAvailableListener {

    /* renamed from: a */
    static final ImageReader.OnImageAvailableListener f77a = new C0029ai();

    private C0029ai() {
    }

    public final void onImageAvailable(ImageReader imageReader) {
        SharedCamera.lambda$setDummyOnImageAvailableListener$0$SharedCamera(imageReader);
    }
}
