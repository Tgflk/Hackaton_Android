package com.google.p010ar.core;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import com.google.p010ar.core.ArCoreApk;
import com.google.p010ar.core.exceptions.FatalException;
import com.google.p010ar.core.exceptions.UnavailableDeviceNotCompatibleException;
import com.google.p010ar.core.exceptions.UnavailableUserDeclinedInstallationException;

/* renamed from: com.google.ar.core.k */
/* compiled from: ArCoreApkImpl */
final class C0051k extends ArCoreApk {

    /* renamed from: c */
    private static final C0051k f110c = new C0051k();

    /* renamed from: a */
    Exception f111a;

    /* renamed from: b */
    boolean f112b = true;

    /* renamed from: d */
    private boolean f113d;

    /* renamed from: e */
    private int f114e;

    /* renamed from: f */
    private long f115f;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public ArCoreApk.Availability f116g;
    /* access modifiers changed from: private */

    /* renamed from: h */
    public boolean f117h;

    /* renamed from: i */
    private C0063w f118i;

    /* renamed from: j */
    private boolean f119j;

    /* renamed from: k */
    private boolean f120k;

    /* renamed from: l */
    private int f121l;

    C0051k() {
    }

    /* renamed from: a */
    public static C0051k m49a() {
        return f110c;
    }

    /* renamed from: g */
    private final boolean m52g(Context context) {
        m55j(context);
        return this.f120k;
    }

    /* renamed from: h */
    private static boolean m53h() {
        return Build.VERSION.SDK_INT >= 24;
    }

    /* renamed from: i */
    private static int m54i(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo("com.google.ar.core", 4);
            int i = packageInfo.versionCode;
            if (i != 0) {
                return i;
            }
            if (packageInfo.services == null || packageInfo.services.length == 0) {
                return -1;
            }
            return 0;
        } catch (PackageManager.NameNotFoundException unused) {
            return -1;
        }
    }

    /* renamed from: j */
    private final synchronized void m55j(Context context) {
        if (!this.f119j) {
            PackageManager packageManager = context.getPackageManager();
            String packageName = context.getPackageName();
            try {
                Bundle bundle = packageManager.getApplicationInfo(packageName, 128).metaData;
                if (bundle.containsKey("com.google.ar.core")) {
                    String string = bundle.getString("com.google.ar.core");
                    string.getClass();
                    this.f120k = string.equals("required");
                    if (bundle.containsKey("com.google.ar.core.min_apk_version")) {
                        this.f121l = bundle.getInt("com.google.ar.core.min_apk_version");
                        ActivityInfo[] activityInfoArr = packageManager.getPackageInfo(packageName, 1).activities;
                        String canonicalName = InstallActivity.class.getCanonicalName();
                        for (ActivityInfo activityInfo : activityInfoArr) {
                            if (canonicalName.equals(activityInfo.name)) {
                                this.f119j = true;
                                return;
                            }
                        }
                        String valueOf = String.valueOf(canonicalName);
                        throw new FatalException(valueOf.length() != 0 ? "Application manifest must contain activity ".concat(valueOf) : new String("Application manifest must contain activity "));
                    }
                    throw new FatalException("Application manifest must contain meta-data com.google.ar.core.min_apk_version");
                }
                throw new FatalException("Application manifest must contain meta-data com.google.ar.core");
            } catch (PackageManager.NameNotFoundException e) {
                throw new FatalException("Could not load application package metadata", e);
            } catch (PackageManager.NameNotFoundException e2) {
                throw new FatalException("Could not load application package info", e2);
            }
        }
    }

    /* renamed from: k */
    private static final ArCoreApk.InstallStatus m56k(Activity activity) throws UnavailableDeviceNotCompatibleException, UnavailableUserDeclinedInstallationException {
        PendingIntent a = C0020a.m36a(activity);
        if (a != null) {
            try {
                Log.i("ARCore-ArCoreApk", "Starting setup activity");
                activity.startIntentSender(a.getIntentSender(), (Intent) null, 0, 0, 0);
                return ArCoreApk.InstallStatus.INSTALL_REQUESTED;
            } catch (IntentSender.SendIntentException | RuntimeException e) {
                Log.w("ARCore-ArCoreApk", "Setup activity launch failed", e);
            }
        }
        return ArCoreApk.InstallStatus.INSTALLED;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public final synchronized C0063w mo342b(Context context) {
        if (this.f118i == null) {
            C0063w wVar = new C0063w((byte[]) null);
            wVar.mo356a(context.getApplicationContext());
            this.f118i = wVar;
        }
        return this.f118i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public final synchronized void mo343c() {
        if (this.f111a == null) {
            this.f114e = 0;
        }
        this.f113d = false;
        C0063w wVar = this.f118i;
        if (wVar != null) {
            wVar.mo357b();
            this.f118i = null;
        }
    }

    /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x001e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final com.google.p010ar.core.ArCoreApk.Availability checkAvailability(android.content.Context r4) {
        /*
            r3 = this;
            boolean r0 = m53h()
            if (r0 != 0) goto L_0x0009
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.UNSUPPORTED_DEVICE_NOT_CAPABLE
            return r4
        L_0x0009:
            boolean r0 = r3.mo344d(r4)     // Catch:{ FatalException -> 0x0083 }
            if (r0 == 0) goto L_0x0024
            r3.mo343c()     // Catch:{ FatalException -> 0x0083 }
            android.app.PendingIntent r4 = com.google.p010ar.core.C0020a.m36a(r4)     // Catch:{ UnavailableDeviceNotCompatibleException -> 0x0021, UnavailableUserDeclinedInstallationException | RuntimeException -> 0x001e }
            if (r4 == 0) goto L_0x001b
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.SUPPORTED_APK_TOO_OLD     // Catch:{ UnavailableDeviceNotCompatibleException -> 0x0021, UnavailableUserDeclinedInstallationException | RuntimeException -> 0x001e }
            goto L_0x0023
        L_0x001b:
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.SUPPORTED_INSTALLED     // Catch:{ UnavailableDeviceNotCompatibleException -> 0x0021, UnavailableUserDeclinedInstallationException | RuntimeException -> 0x001e }
            goto L_0x0023
        L_0x001e:
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.UNKNOWN_ERROR     // Catch:{ FatalException -> 0x0083 }
            goto L_0x0023
        L_0x0021:
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.UNSUPPORTED_DEVICE_NOT_CAPABLE     // Catch:{ FatalException -> 0x0083 }
        L_0x0023:
            return r4
        L_0x0024:
            monitor-enter(r3)
            com.google.ar.core.ArCoreApk$Availability r0 = r3.f116g     // Catch:{ all -> 0x0080 }
            if (r0 == 0) goto L_0x002f
            boolean r0 = r0.isUnknown()     // Catch:{ all -> 0x0080 }
            if (r0 == 0) goto L_0x0067
        L_0x002f:
            boolean r0 = r3.f117h     // Catch:{ all -> 0x0080 }
            if (r0 != 0) goto L_0x0067
            r0 = 1
            r3.f117h = r0     // Catch:{ all -> 0x0080 }
            com.google.ar.core.j r0 = new com.google.ar.core.j     // Catch:{ all -> 0x0080 }
            r0.<init>(r3)     // Catch:{ all -> 0x0080 }
            boolean r1 = r3.mo344d(r4)     // Catch:{ all -> 0x0080 }
            if (r1 == 0) goto L_0x0047
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.SUPPORTED_INSTALLED     // Catch:{ all -> 0x0080 }
            r0.mo341a(r4)     // Catch:{ all -> 0x0080 }
            goto L_0x0067
        L_0x0047:
            int r1 = m54i(r4)     // Catch:{ all -> 0x0080 }
            r2 = -1
            if (r1 == r2) goto L_0x0054
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.SUPPORTED_APK_TOO_OLD     // Catch:{ all -> 0x0080 }
            r0.mo341a(r4)     // Catch:{ all -> 0x0080 }
            goto L_0x0067
        L_0x0054:
            boolean r1 = r3.m52g(r4)     // Catch:{ all -> 0x0080 }
            if (r1 == 0) goto L_0x0060
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED     // Catch:{ all -> 0x0080 }
            r0.mo341a(r4)     // Catch:{ all -> 0x0080 }
            goto L_0x0067
        L_0x0060:
            com.google.ar.core.w r1 = r3.mo342b(r4)     // Catch:{ all -> 0x0080 }
            r1.mo358c(r4, r0)     // Catch:{ all -> 0x0080 }
        L_0x0067:
            com.google.ar.core.ArCoreApk$Availability r4 = r3.f116g     // Catch:{ all -> 0x0080 }
            if (r4 == 0) goto L_0x006d
            monitor-exit(r3)     // Catch:{ all -> 0x0080 }
            return r4
        L_0x006d:
            boolean r4 = r3.f117h     // Catch:{ all -> 0x0080 }
            if (r4 == 0) goto L_0x0075
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.UNKNOWN_CHECKING     // Catch:{ all -> 0x0080 }
            monitor-exit(r3)     // Catch:{ all -> 0x0080 }
            return r4
        L_0x0075:
            java.lang.String r4 = "ARCore-ArCoreApk"
            java.lang.String r0 = "request not running but result is null?"
            android.util.Log.e(r4, r0)     // Catch:{ all -> 0x0080 }
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.UNKNOWN_ERROR     // Catch:{ all -> 0x0080 }
            monitor-exit(r3)     // Catch:{ all -> 0x0080 }
            return r4
        L_0x0080:
            r4 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0080 }
            throw r4
        L_0x0083:
            r4 = move-exception
            java.lang.String r0 = "ARCore-ArCoreApk"
            java.lang.String r1 = "Error while checking app details and ARCore status"
            android.util.Log.e(r0, r1, r4)
            com.google.ar.core.ArCoreApk$Availability r4 = com.google.p010ar.core.ArCoreApk.Availability.UNKNOWN_ERROR
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.p010ar.core.C0051k.checkAvailability(android.content.Context):com.google.ar.core.ArCoreApk$Availability");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public final boolean mo344d(Context context) {
        m55j(context);
        return m54i(context) == 0 || m54i(context) >= this.f121l;
    }

    public final ArCoreApk.InstallStatus requestInstall(Activity activity, boolean z) throws UnavailableDeviceNotCompatibleException, UnavailableUserDeclinedInstallationException {
        ArCoreApk.UserMessageType userMessageType;
        ArCoreApk.InstallBehavior installBehavior = m52g(activity) ? ArCoreApk.InstallBehavior.REQUIRED : ArCoreApk.InstallBehavior.OPTIONAL;
        if (m52g(activity)) {
            userMessageType = ArCoreApk.UserMessageType.APPLICATION;
        } else {
            userMessageType = ArCoreApk.UserMessageType.USER_ALREADY_INFORMED;
        }
        return requestInstall(activity, z, installBehavior, userMessageType);
    }

    public final ArCoreApk.InstallStatus requestInstall(Activity activity, boolean z, ArCoreApk.InstallBehavior installBehavior, ArCoreApk.UserMessageType userMessageType) throws UnavailableDeviceNotCompatibleException, UnavailableUserDeclinedInstallationException {
        if (!m53h()) {
            throw new UnavailableDeviceNotCompatibleException();
        } else if (mo344d(activity)) {
            mo343c();
            return m56k(activity);
        } else if (this.f113d) {
            return ArCoreApk.InstallStatus.INSTALL_REQUESTED;
        } else {
            Exception exc = this.f111a;
            if (exc != null) {
                if (z) {
                    Log.w("ARCore-ArCoreApk", "Clearing previous failure: ", exc);
                    this.f111a = null;
                } else if (exc instanceof UnavailableDeviceNotCompatibleException) {
                    throw ((UnavailableDeviceNotCompatibleException) exc);
                } else if (exc instanceof UnavailableUserDeclinedInstallationException) {
                    throw ((UnavailableUserDeclinedInstallationException) exc);
                } else if (exc instanceof RuntimeException) {
                    throw ((RuntimeException) exc);
                } else {
                    throw new RuntimeException("Unexpected exception type", exc);
                }
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            if (uptimeMillis - this.f115f > 5000) {
                this.f114e = 0;
            }
            int i = this.f114e + 1;
            this.f114e = i;
            this.f115f = uptimeMillis;
            if (i <= 2) {
                try {
                    activity.startActivity(new Intent(activity, InstallActivity.class).putExtra("message", userMessageType).putExtra("behavior", installBehavior));
                    this.f113d = true;
                    return ArCoreApk.InstallStatus.INSTALL_REQUESTED;
                } catch (ActivityNotFoundException e) {
                    throw new FatalException("Failed to launch InstallActivity", e);
                }
            } else {
                throw new FatalException("Requesting ARCore installation too rapidly.");
            }
        }
    }
}
