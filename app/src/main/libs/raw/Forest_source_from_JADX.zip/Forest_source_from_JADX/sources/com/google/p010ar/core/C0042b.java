package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* 'enum' modifier removed */
/* renamed from: com.google.ar.core.b */
/* compiled from: ArCoreApk */
final class C0042b extends ArCoreApk.Availability {
    C0042b() {
        super("UNKNOWN_ERROR", 0, 0, (C0020a) null);
    }

    public final boolean isUnknown() {
        return true;
    }
}
