package com.unity3d.player;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.google.android.play.core.assetpacks.AssetPackLocation;
import com.google.android.play.core.assetpacks.AssetPackManager;
import com.google.android.play.core.assetpacks.AssetPackManagerFactory;
import com.google.android.play.core.assetpacks.AssetPackState;
import com.google.android.play.core.assetpacks.AssetPackStateUpdateListener;
import com.google.android.play.core.assetpacks.AssetPackStates;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.google.android.play.core.tasks.RuntimeExecutionException;
import com.google.android.play.core.tasks.Task;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/* renamed from: com.unity3d.player.a */
final class C0116a implements C0134d {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public static C0116a f282a;

    /* renamed from: b */
    private AssetPackManager f283b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public HashSet f284c;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public Object f285d;

    /* renamed from: com.unity3d.player.a$a */
    private static class C0117a implements Runnable {

        /* renamed from: a */
        private Set f286a;

        /* renamed from: b */
        private String f287b;

        /* renamed from: c */
        private int f288c;

        /* renamed from: d */
        private long f289d;

        /* renamed from: e */
        private long f290e;

        /* renamed from: f */
        private int f291f;

        /* renamed from: g */
        private int f292g;

        C0117a(Set set, String str, int i, long j, long j2, int i2, int i3) {
            this.f286a = set;
            this.f287b = str;
            this.f288c = i;
            this.f289d = j;
            this.f290e = j2;
            this.f291f = i2;
            this.f292g = i3;
        }

        public final void run() {
            for (IAssetPackManagerDownloadStatusCallback onStatusUpdate : this.f286a) {
                onStatusUpdate.onStatusUpdate(this.f287b, this.f288c, this.f289d, this.f290e, this.f291f, this.f292g);
            }
        }
    }

    /* renamed from: com.unity3d.player.a$b */
    private class C0118b implements AssetPackStateUpdateListener {

        /* renamed from: b */
        private HashSet f294b;

        /* renamed from: c */
        private Looper f295c;

        public C0118b(C0116a aVar, IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback) {
            this(iAssetPackManagerDownloadStatusCallback, Looper.myLooper());
        }

        public C0118b(IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback, Looper looper) {
            HashSet hashSet = new HashSet();
            this.f294b = hashSet;
            hashSet.add(iAssetPackManagerDownloadStatusCallback);
            this.f295c = looper;
        }

        /* renamed from: a */
        private static Set m149a(HashSet hashSet) {
            return (Set) hashSet.clone();
        }

        /* access modifiers changed from: private */
        /* renamed from: a */
        public synchronized void onStateUpdate(AssetPackState assetPackState) {
            if (assetPackState.status() == 4 || assetPackState.status() == 5 || assetPackState.status() == 0) {
                synchronized (C0116a.f282a) {
                    C0116a.this.f284c.remove(assetPackState.name());
                    if (C0116a.this.f284c.isEmpty()) {
                        C0116a.this.mo550a(C0116a.this.f285d);
                        Object unused = C0116a.this.f285d = null;
                    }
                }
            }
            if (this.f294b.size() != 0) {
                new Handler(this.f295c).post(new C0117a(m149a(this.f294b), assetPackState.name(), assetPackState.status(), assetPackState.totalBytesToDownload(), assetPackState.bytesDownloaded(), assetPackState.transferProgressPercentage(), assetPackState.errorCode()));
            }
        }

        /* renamed from: a */
        public final synchronized void mo556a(IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback) {
            this.f294b.add(iAssetPackManagerDownloadStatusCallback);
        }
    }

    /* renamed from: com.unity3d.player.a$c */
    private static class C0119c implements OnSuccessListener {

        /* renamed from: a */
        private IAssetPackManagerMobileDataConfirmationCallback f296a;

        /* renamed from: b */
        private Looper f297b = Looper.myLooper();

        /* renamed from: com.unity3d.player.a$c$a */
        private static class C0120a implements Runnable {

            /* renamed from: a */
            private IAssetPackManagerMobileDataConfirmationCallback f298a;

            /* renamed from: b */
            private boolean f299b;

            C0120a(IAssetPackManagerMobileDataConfirmationCallback iAssetPackManagerMobileDataConfirmationCallback, boolean z) {
                this.f298a = iAssetPackManagerMobileDataConfirmationCallback;
                this.f299b = z;
            }

            public final void run() {
                this.f298a.onMobileDataConfirmationResult(this.f299b);
            }
        }

        public C0119c(IAssetPackManagerMobileDataConfirmationCallback iAssetPackManagerMobileDataConfirmationCallback) {
            this.f296a = iAssetPackManagerMobileDataConfirmationCallback;
        }

        /* access modifiers changed from: private */
        /* renamed from: a */
        public void onSuccess(Integer num) {
            if (this.f296a != null) {
                new Handler(this.f297b).post(new C0120a(this.f296a, num.intValue() == -1));
            }
        }
    }

    /* renamed from: com.unity3d.player.a$d */
    private static class C0121d implements OnCompleteListener {

        /* renamed from: a */
        private IAssetPackManagerDownloadStatusCallback f300a;

        /* renamed from: b */
        private Looper f301b = Looper.myLooper();

        /* renamed from: c */
        private String f302c;

        public C0121d(IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback, String str) {
            this.f300a = iAssetPackManagerDownloadStatusCallback;
            this.f302c = str;
        }

        /* renamed from: a */
        private void m153a(String str, int i, int i2, long j) {
            new Handler(this.f301b).post(new C0117a(Collections.singleton(this.f300a), str, i, j, i == 4 ? j : 0, 0, i2));
        }

        public final void onComplete(Task task) {
            try {
                AssetPackStates assetPackStates = (AssetPackStates) task.getResult();
                Map packStates = assetPackStates.packStates();
                if (packStates.size() != 0) {
                    for (AssetPackState assetPackState : packStates.values()) {
                        if (assetPackState.errorCode() != 0 || assetPackState.status() == 4 || assetPackState.status() == 5 || assetPackState.status() == 0) {
                            m153a(assetPackState.name(), assetPackState.status(), assetPackState.errorCode(), assetPackStates.totalBytes());
                        } else {
                            C0116a.f282a.m138a(assetPackState.name(), this.f300a, this.f301b);
                        }
                    }
                }
            } catch (RuntimeExecutionException e) {
                m153a(this.f302c, 0, e.getErrorCode(), 0);
            }
        }
    }

    /* renamed from: com.unity3d.player.a$e */
    private static class C0122e implements OnCompleteListener {

        /* renamed from: a */
        private IAssetPackManagerStatusQueryCallback f303a;

        /* renamed from: b */
        private Looper f304b = Looper.myLooper();

        /* renamed from: c */
        private String[] f305c;

        /* renamed from: com.unity3d.player.a$e$a */
        private static class C0123a implements Runnable {

            /* renamed from: a */
            private IAssetPackManagerStatusQueryCallback f306a;

            /* renamed from: b */
            private long f307b;

            /* renamed from: c */
            private String[] f308c;

            /* renamed from: d */
            private int[] f309d;

            /* renamed from: e */
            private int[] f310e;

            C0123a(IAssetPackManagerStatusQueryCallback iAssetPackManagerStatusQueryCallback, long j, String[] strArr, int[] iArr, int[] iArr2) {
                this.f306a = iAssetPackManagerStatusQueryCallback;
                this.f307b = j;
                this.f308c = strArr;
                this.f309d = iArr;
                this.f310e = iArr2;
            }

            public final void run() {
                this.f306a.onStatusResult(this.f307b, this.f308c, this.f309d, this.f310e);
            }
        }

        public C0122e(IAssetPackManagerStatusQueryCallback iAssetPackManagerStatusQueryCallback, String[] strArr) {
            this.f303a = iAssetPackManagerStatusQueryCallback;
            this.f305c = strArr;
        }

        public final void onComplete(Task task) {
            if (this.f303a != null) {
                int i = 0;
                try {
                    AssetPackStates assetPackStates = (AssetPackStates) task.getResult();
                    Map packStates = assetPackStates.packStates();
                    int size = packStates.size();
                    String[] strArr = new String[size];
                    int[] iArr = new int[size];
                    int[] iArr2 = new int[size];
                    for (AssetPackState assetPackState : packStates.values()) {
                        strArr[i] = assetPackState.name();
                        iArr[i] = assetPackState.status();
                        iArr2[i] = assetPackState.errorCode();
                        i++;
                    }
                    new Handler(this.f304b).post(new C0123a(this.f303a, assetPackStates.totalBytes(), strArr, iArr, iArr2));
                } catch (RuntimeExecutionException e) {
                    String message = e.getMessage();
                    for (String str : this.f305c) {
                        if (message.contains(str)) {
                            new Handler(this.f304b).post(new C0123a(this.f303a, 0, new String[]{str}, new int[]{0}, new int[]{e.getErrorCode()}));
                            return;
                        }
                    }
                    String[] strArr2 = this.f305c;
                    int[] iArr3 = new int[strArr2.length];
                    int[] iArr4 = new int[strArr2.length];
                    for (int i2 = 0; i2 < this.f305c.length; i2++) {
                        iArr3[i2] = 0;
                        iArr4[i2] = e.getErrorCode();
                    }
                    new Handler(this.f304b).post(new C0123a(this.f303a, 0, this.f305c, iArr3, iArr4));
                }
            }
        }
    }

    private C0116a(Context context) {
        if (f282a == null) {
            this.f283b = AssetPackManagerFactory.getInstance(context);
            this.f284c = new HashSet();
            return;
        }
        throw new RuntimeException("AssetPackManagerWrapper should be created only once. Use getInstance() instead.");
    }

    /* renamed from: a */
    public static C0134d m135a(Context context) {
        if (f282a == null) {
            f282a = new C0116a(context);
        }
        return f282a;
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m138a(String str, IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback, Looper looper) {
        synchronized (f282a) {
            if (this.f285d == null) {
                C0118b bVar = new C0118b(iAssetPackManagerDownloadStatusCallback, looper);
                this.f283b.registerListener(bVar);
                this.f285d = bVar;
            } else {
                ((C0118b) this.f285d).mo556a(iAssetPackManagerDownloadStatusCallback);
            }
            this.f284c.add(str);
            this.f283b.fetch(Collections.singletonList(str));
        }
    }

    /* renamed from: a */
    public final Object mo547a(IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback) {
        C0118b bVar = new C0118b(this, iAssetPackManagerDownloadStatusCallback);
        this.f283b.registerListener(bVar);
        return bVar;
    }

    /* renamed from: a */
    public final String mo548a(String str) {
        AssetPackLocation packLocation = this.f283b.getPackLocation(str);
        return packLocation == null ? "" : packLocation.assetsPath();
    }

    /* renamed from: a */
    public final void mo549a(Activity activity, IAssetPackManagerMobileDataConfirmationCallback iAssetPackManagerMobileDataConfirmationCallback) {
        this.f283b.showCellularDataConfirmation(activity).addOnSuccessListener(new C0119c(iAssetPackManagerMobileDataConfirmationCallback));
    }

    /* renamed from: a */
    public final void mo550a(Object obj) {
        if (obj instanceof C0118b) {
            this.f283b.unregisterListener((C0118b) obj);
        }
    }

    /* renamed from: a */
    public final void mo551a(String[] strArr) {
        this.f283b.cancel(Arrays.asList(strArr));
    }

    /* renamed from: a */
    public final void mo552a(String[] strArr, IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback) {
        for (String str : strArr) {
            this.f283b.getPackStates(Collections.singletonList(str)).addOnCompleteListener(new C0121d(iAssetPackManagerDownloadStatusCallback, str));
        }
    }

    /* renamed from: a */
    public final void mo553a(String[] strArr, IAssetPackManagerStatusQueryCallback iAssetPackManagerStatusQueryCallback) {
        this.f283b.getPackStates(Arrays.asList(strArr)).addOnCompleteListener(new C0122e(iAssetPackManagerStatusQueryCallback, strArr));
    }

    /* renamed from: b */
    public final void mo554b(String str) {
        this.f283b.removePack(str);
    }
}
