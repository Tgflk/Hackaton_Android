package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* 'enum' modifier removed */
/* renamed from: com.google.ar.core.f */
/* compiled from: ArCoreApk */
final class C0046f extends ArCoreApk.Availability {
    C0046f() {
        super("SUPPORTED_NOT_INSTALLED", 4, 201, (C0020a) null);
    }

    public final boolean isSupported() {
        return true;
    }
}
