package com.unity3d.player;

/* renamed from: com.unity3d.player.e */
public interface C0135e {
    /* renamed from: a */
    void mo376a(Object obj);

    /* renamed from: a */
    void mo377a(Object obj, Object obj2, Object obj3, int i, int i2, int i3);
}
