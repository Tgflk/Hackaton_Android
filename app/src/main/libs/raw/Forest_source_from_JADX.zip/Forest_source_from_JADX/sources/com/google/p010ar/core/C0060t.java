package com.google.p010ar.core;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: com.google.ar.core.t */
/* compiled from: InstallActivity */
final class C0060t extends AnimatorListenerAdapter {

    /* renamed from: a */
    final /* synthetic */ InstallActivity f136a;

    C0060t(InstallActivity installActivity) {
        this.f136a = installActivity;
    }

    public final void onAnimationEnd(Animator animator) {
        this.f136a.showSpinner();
    }
}
