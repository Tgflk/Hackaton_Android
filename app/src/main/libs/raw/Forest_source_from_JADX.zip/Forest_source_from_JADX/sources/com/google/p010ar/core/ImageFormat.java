package com.google.p010ar.core;

/* renamed from: com.google.ar.core.ImageFormat */
public class ImageFormat {
    public static final int RGBA_FP16 = 22;
    public static final int YUV_420_888 = 35;

    private ImageFormat() {
    }
}
