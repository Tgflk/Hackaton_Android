package com.unity.p012xr.arpresto;

/* renamed from: com.unity.xr.arpresto.R */
public final class C0074R {
    private C0074R() {
    }
}
