package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;
import com.google.p010ar.core.exceptions.UnavailableUserDeclinedInstallationException;

/* renamed from: com.google.ar.core.u */
/* compiled from: InstallActivity */
final class C0061u {

    /* renamed from: a */
    boolean f137a = false;

    /* renamed from: b */
    final /* synthetic */ InstallActivity f138b;

    C0061u(InstallActivity installActivity) {
        this.f138b = installActivity;
    }

    /* renamed from: a */
    public final void mo354a(C0062v vVar) {
        synchronized (this.f138b) {
            if (!this.f137a) {
                C0062v unused = this.f138b.lastEvent = vVar;
                C0062v vVar2 = C0062v.ACCEPTED;
                ArCoreApk.UserMessageType userMessageType = ArCoreApk.UserMessageType.APPLICATION;
                ArCoreApk.Availability availability = ArCoreApk.Availability.UNKNOWN_ERROR;
                int ordinal = vVar.ordinal();
                if (ordinal != 0) {
                    if (ordinal == 1) {
                        this.f138b.finishWithFailure(new UnavailableUserDeclinedInstallationException());
                    } else if (ordinal == 2) {
                        if (!this.f138b.waitingForCompletion && C0051k.m49a().f112b) {
                            this.f138b.closeInstaller();
                        }
                        this.f138b.finishWithFailure((Exception) null);
                    }
                    this.f137a = true;
                }
            }
        }
    }

    /* renamed from: b */
    public final void mo355b(Exception exc) {
        synchronized (this.f138b) {
            if (!this.f137a) {
                this.f137a = true;
                C0062v unused = this.f138b.lastEvent = C0062v.CANCELLED;
                this.f138b.finishWithFailure(exc);
            }
        }
    }
}
