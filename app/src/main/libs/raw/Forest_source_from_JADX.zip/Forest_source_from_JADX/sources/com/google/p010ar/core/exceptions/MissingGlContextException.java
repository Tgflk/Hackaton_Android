package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.MissingGlContextException */
public class MissingGlContextException extends IllegalStateException {
    public MissingGlContextException() {
    }

    public MissingGlContextException(String str) {
        super(str);
    }
}
