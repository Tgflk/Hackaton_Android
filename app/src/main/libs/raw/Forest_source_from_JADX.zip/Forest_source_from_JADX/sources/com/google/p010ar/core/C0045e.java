package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* 'enum' modifier removed */
/* renamed from: com.google.ar.core.e */
/* compiled from: ArCoreApk */
final class C0045e extends ArCoreApk.Availability {
    C0045e() {
        super("UNSUPPORTED_DEVICE_NOT_CAPABLE", 3, 100, (C0020a) null);
    }

    public final boolean isUnsupported() {
        return true;
    }
}
