package com.unity.p012xr.arcore;

/* renamed from: com.unity.xr.arcore.BuildConfig */
public final class BuildConfig {
    @Deprecated
    public static final String APPLICATION_ID = "com.unity.xr.arcore";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String LIBRARY_PACKAGE_NAME = "com.unity.xr.arcore";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}
