package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.UnavailableException */
public class UnavailableException extends Exception {
    public UnavailableException() {
    }

    public UnavailableException(String str) {
        super(str);
    }
}
