package com.unity3d.player;

import android.content.Context;
import com.unity3d.player.C0124b;

public class AudioVolumeHandler implements C0124b.C0126b {

    /* renamed from: a */
    private C0124b f164a;

    AudioVolumeHandler(Context context) {
        C0124b bVar = new C0124b(context);
        this.f164a = bVar;
        bVar.mo564a(this);
    }

    /* renamed from: a */
    public final void mo373a() {
        this.f164a.mo563a();
        this.f164a = null;
    }

    public final native void onAudioVolumeChanged(int i);
}
