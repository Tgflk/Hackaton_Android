package com.google.p011vr.dynamite.client;

import java.util.Objects;

/* renamed from: com.google.vr.dynamite.client.f */
/* compiled from: TargetLibraryInfo */
final class C0072f {

    /* renamed from: a */
    private final String f162a;

    /* renamed from: b */
    private final String f163b;

    public C0072f(String str, String str2) {
        this.f162a = str;
        this.f163b = str2;
    }

    /* renamed from: a */
    public final String mo369a() {
        return this.f162a;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof C0072f) {
            C0072f fVar = (C0072f) obj;
            return Objects.equals(this.f162a, fVar.f162a) && Objects.equals(this.f163b, fVar.f163b);
        }
    }

    public final int hashCode() {
        return (Objects.hashCode(this.f162a) * 37) + Objects.hashCode(this.f163b);
    }

    public final String toString() {
        return "[packageName=" + this.f162a + ",libraryName=" + this.f163b + "]";
    }
}
