package com.google.p010ar.core;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.util.Log;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.google.ar.core.ae */
/* compiled from: InstallServiceImpl */
final class C0025ae implements Runnable {

    /* renamed from: a */
    final /* synthetic */ Activity f30a;

    /* renamed from: b */
    final /* synthetic */ C0061u f31b;

    /* renamed from: c */
    final /* synthetic */ C0063w f32c;

    C0025ae(C0063w wVar, Activity activity, C0061u uVar) {
        this.f32c = wVar;
        this.f30a = activity;
        this.f31b = uVar;
    }

    public final void run() {
        try {
            AtomicBoolean atomicBoolean = new AtomicBoolean(false);
            this.f32c.f145c.mo11d(this.f30a.getApplicationInfo().packageName, Collections.singletonList(C0063w.m70k()), new Bundle(), new C0023ac(this, atomicBoolean));
            new Handler().postDelayed(new C0024ad(this, atomicBoolean), 3000);
        } catch (RemoteException e) {
            Log.w("ARCore-InstallService", "requestInstall threw, launching fullscreen.", e);
            C0063w.m74o(this.f30a, this.f31b);
        }
    }
}
