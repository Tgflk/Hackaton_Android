package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.UnavailableSdkTooOldException */
public class UnavailableSdkTooOldException extends UnavailableException {
    public UnavailableSdkTooOldException() {
    }

    public UnavailableSdkTooOldException(String str) {
        super(str);
    }
}
