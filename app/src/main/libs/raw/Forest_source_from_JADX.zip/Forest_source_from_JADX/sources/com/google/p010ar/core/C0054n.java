package com.google.p010ar.core;

import java.util.Map;

/* renamed from: com.google.ar.core.n */
/* compiled from: FaceCache */
final class C0054n {

    /* renamed from: a */
    final Map<Long, AugmentedFace> f125a = new C0053m();

    C0054n() {
    }

    /* renamed from: a */
    public final synchronized AugmentedFace mo349a(long j, Session session) {
        Map<Long, AugmentedFace> map = this.f125a;
        Long valueOf = Long.valueOf(j);
        AugmentedFace augmentedFace = map.get(valueOf);
        if (augmentedFace != null) {
            return augmentedFace;
        }
        AugmentedFace augmentedFace2 = new AugmentedFace(j, session);
        this.f125a.put(valueOf, augmentedFace2);
        return augmentedFace2;
    }
}
