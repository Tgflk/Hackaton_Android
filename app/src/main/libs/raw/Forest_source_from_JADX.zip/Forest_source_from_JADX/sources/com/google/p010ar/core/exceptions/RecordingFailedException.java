package com.google.p010ar.core.exceptions;

import java.io.IOException;

/* renamed from: com.google.ar.core.exceptions.RecordingFailedException */
public class RecordingFailedException extends IOException {
    public RecordingFailedException() {
    }

    public RecordingFailedException(String str) {
        super(str);
    }
}
