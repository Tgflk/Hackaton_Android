package com.unity3d.player;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.unity3d.plugin.PermissionFragment;

/* renamed from: com.unity3d.player.g */
public final class C0137g extends Fragment {

    /* renamed from: a */
    private final IPermissionRequestCallbacks f359a;

    /* renamed from: b */
    private final Activity f360b;

    /* renamed from: c */
    private final Looper f361c;

    /* renamed from: com.unity3d.player.g$a */
    class C0138a implements Runnable {

        /* renamed from: b */
        private IPermissionRequestCallbacks f363b;

        /* renamed from: c */
        private String f364c;

        /* renamed from: d */
        private int f365d;

        /* renamed from: e */
        private boolean f366e;

        C0138a(IPermissionRequestCallbacks iPermissionRequestCallbacks, String str, int i, boolean z) {
            this.f363b = iPermissionRequestCallbacks;
            this.f364c = str;
            this.f365d = i;
            this.f366e = z;
        }

        public final void run() {
            int i = this.f365d;
            if (i == -1) {
                if (this.f366e) {
                    this.f363b.onPermissionDenied(this.f364c);
                } else {
                    this.f363b.onPermissionDeniedAndDontAskAgain(this.f364c);
                }
            } else if (i == 0) {
                this.f363b.onPermissionGranted(this.f364c);
            }
        }
    }

    public C0137g() {
        this.f359a = null;
        this.f360b = null;
        this.f361c = null;
    }

    public C0137g(Activity activity, IPermissionRequestCallbacks iPermissionRequestCallbacks) {
        this.f359a = iPermissionRequestCallbacks;
        this.f360b = activity;
        this.f361c = Looper.myLooper();
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestPermissions(getArguments().getStringArray(PermissionFragment.PERMISSION_NAMES), 96489);
    }

    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 96489) {
            if (strArr.length == 0) {
                requestPermissions(getArguments().getStringArray(PermissionFragment.PERMISSION_NAMES), 96489);
                return;
            }
            int i2 = 0;
            while (i2 < strArr.length && i2 < iArr.length) {
                if (!(this.f359a == null || this.f360b == null || this.f361c == null)) {
                    String str = strArr[i2] == null ? "<null>" : strArr[i2];
                    new Handler(this.f361c).post(new C0138a(this.f359a, str, iArr[i2], this.f360b.shouldShowRequestPermissionRationale(str)));
                }
                i2++;
            }
            FragmentTransaction beginTransaction = getActivity().getFragmentManager().beginTransaction();
            beginTransaction.remove(this);
            beginTransaction.commit();
        }
    }
}
