package com.google.p010ar.core;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import com.google.p010ar.core.ArCoreApk;
import com.google.p010ar.core.exceptions.ResourceExhaustedException;
import com.google.p010ar.core.exceptions.UnavailableApkTooOldException;
import com.google.p010ar.core.exceptions.UnavailableArcoreNotInstalledException;
import com.google.p010ar.core.exceptions.UnavailableDeviceNotCompatibleException;
import com.google.p010ar.core.exceptions.UnavailableSdkTooOldException;
import com.google.p010ar.core.exceptions.UnavailableUserDeclinedInstallationException;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.ar.core.ArCoreApkJniAdapter */
class ArCoreApkJniAdapter {

    /* renamed from: a */
    private static final Map<Class<? extends Throwable>, Integer> f14a;

    static {
        HashMap hashMap = new HashMap();
        f14a = hashMap;
        hashMap.put(IllegalArgumentException.class, Integer.valueOf(C0027ag.ERROR_INVALID_ARGUMENT.f64E));
        f14a.put(ResourceExhaustedException.class, Integer.valueOf(C0027ag.ERROR_RESOURCE_EXHAUSTED.f64E));
        f14a.put(UnavailableArcoreNotInstalledException.class, Integer.valueOf(C0027ag.UNAVAILABLE_ARCORE_NOT_INSTALLED.f64E));
        f14a.put(UnavailableDeviceNotCompatibleException.class, Integer.valueOf(C0027ag.UNAVAILABLE_DEVICE_NOT_COMPATIBLE.f64E));
        f14a.put(UnavailableApkTooOldException.class, Integer.valueOf(C0027ag.UNAVAILABLE_APK_TOO_OLD.f64E));
        f14a.put(UnavailableSdkTooOldException.class, Integer.valueOf(C0027ag.UNAVAILABLE_SDK_TOO_OLD.f64E));
        f14a.put(UnavailableUserDeclinedInstallationException.class, Integer.valueOf(C0027ag.UNAVAILABLE_USER_DECLINED_INSTALLATION.f64E));
    }

    ArCoreApkJniAdapter() {
    }

    /* renamed from: a */
    private static int m17a(Throwable th) {
        Log.e("ARCore-ArCoreApkJniAdapter", "Exception details:", th);
        Class<?> cls = th.getClass();
        if (f14a.containsKey(cls)) {
            return f14a.get(cls).intValue();
        }
        return C0027ag.ERROR_FATAL.f64E;
    }

    static int checkAvailability(Context context) {
        try {
            return ArCoreApk.getInstance().checkAvailability(context).nativeCode;
        } catch (Throwable th) {
            m17a(th);
            return ArCoreApk.Availability.UNKNOWN_ERROR.nativeCode;
        }
    }

    static int requestInstall(Activity activity, boolean z, int[] iArr) throws UnavailableDeviceNotCompatibleException, UnavailableUserDeclinedInstallationException {
        try {
            iArr[0] = ArCoreApk.getInstance().requestInstall(activity, z).nativeCode;
            return C0027ag.SUCCESS.f64E;
        } catch (Throwable th) {
            return m17a(th);
        }
    }

    static int requestInstallCustom(Activity activity, boolean z, int i, int i2, int[] iArr) throws UnavailableDeviceNotCompatibleException, UnavailableUserDeclinedInstallationException {
        try {
            iArr[0] = ArCoreApk.getInstance().requestInstall(activity, z, ArCoreApk.InstallBehavior.forNumber(i), ArCoreApk.UserMessageType.forNumber(i2)).nativeCode;
            return C0027ag.SUCCESS.f64E;
        } catch (Throwable th) {
            return m17a(th);
        }
    }
}
