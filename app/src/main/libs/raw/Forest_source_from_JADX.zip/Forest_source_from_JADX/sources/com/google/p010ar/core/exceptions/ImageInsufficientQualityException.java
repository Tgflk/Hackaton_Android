package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.ImageInsufficientQualityException */
public class ImageInsufficientQualityException extends IllegalArgumentException {
    public ImageInsufficientQualityException() {
    }

    public ImageInsufficientQualityException(String str) {
        super(str);
    }
}
