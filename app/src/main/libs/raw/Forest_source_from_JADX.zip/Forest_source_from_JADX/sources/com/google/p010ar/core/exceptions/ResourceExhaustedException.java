package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.ResourceExhaustedException */
public class ResourceExhaustedException extends RuntimeException {
    public ResourceExhaustedException() {
    }

    public ResourceExhaustedException(String str) {
        super(str);
    }
}
