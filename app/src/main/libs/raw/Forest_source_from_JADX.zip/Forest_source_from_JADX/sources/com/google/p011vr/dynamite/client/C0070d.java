package com.google.p011vr.dynamite.client;

/* renamed from: com.google.vr.dynamite.client.d */
/* compiled from: LoaderException */
public final class C0070d extends Exception {

    /* renamed from: a */
    private final int f158a = 1;

    public final String getMessage() {
        String str = this.f158a != 1 ? "Unknown error" : "Package not available";
        StringBuilder sb = new StringBuilder(str.length() + 17);
        sb.append("LoaderException{");
        sb.append(str);
        sb.append("}");
        return sb.toString();
    }
}
