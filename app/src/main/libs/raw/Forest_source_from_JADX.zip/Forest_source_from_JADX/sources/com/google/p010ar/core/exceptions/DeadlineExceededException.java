package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.DeadlineExceededException */
public class DeadlineExceededException extends IllegalStateException {
    public DeadlineExceededException() {
    }

    public DeadlineExceededException(String str) {
        super(str);
    }
}
