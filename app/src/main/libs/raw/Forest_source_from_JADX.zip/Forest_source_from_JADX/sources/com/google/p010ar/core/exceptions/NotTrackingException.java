package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.NotTrackingException */
public class NotTrackingException extends RuntimeException {
    public NotTrackingException() {
    }

    public NotTrackingException(String str) {
        super(str);
    }
}
