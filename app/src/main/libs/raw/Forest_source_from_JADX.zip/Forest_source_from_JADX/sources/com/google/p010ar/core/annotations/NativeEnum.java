package com.google.p010ar.core.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
/* renamed from: com.google.ar.core.annotations.NativeEnum */
public @interface NativeEnum {
    String value();
}
