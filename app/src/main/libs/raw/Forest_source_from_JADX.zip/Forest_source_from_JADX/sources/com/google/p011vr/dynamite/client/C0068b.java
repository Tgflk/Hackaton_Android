package com.google.p011vr.dynamite.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.p004a.p005a.C0006a;

/* renamed from: com.google.vr.dynamite.client.b */
/* compiled from: INativeLibraryLoader */
public final class C0068b extends C0006a implements INativeLibraryLoader {
    C0068b(IBinder iBinder) {
        super(iBinder, "com.google.vr.dynamite.client.INativeLibraryLoader");
    }

    public final int checkVersion(String str) throws RemoteException {
        Parcel a = mo4a();
        a.writeString(str);
        Parcel b = mo6b(2, a);
        int readInt = b.readInt();
        b.recycle();
        return readInt;
    }

    public final long initializeAndLoadNativeLibrary(String str) throws RemoteException {
        Parcel a = mo4a();
        a.writeString(str);
        Parcel b = mo6b(1, a);
        long readLong = b.readLong();
        b.recycle();
        return readLong;
    }
}
