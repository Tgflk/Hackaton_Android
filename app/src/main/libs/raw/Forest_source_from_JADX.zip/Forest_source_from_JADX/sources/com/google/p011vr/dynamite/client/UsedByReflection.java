package com.google.p011vr.dynamite.client;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE, ElementType.CONSTRUCTOR})
/* renamed from: com.google.vr.dynamite.client.UsedByReflection */
public @interface UsedByReflection {
}
