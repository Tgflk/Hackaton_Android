package com.google.p010ar.core;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import com.google.p004a.p006b.p007a.p008a.p009a.C0012d;
import com.google.p010ar.core.ArCoreApk;

/* renamed from: com.google.ar.core.y */
/* compiled from: InstallServiceImpl */
final class C0065y extends C0012d {

    /* renamed from: a */
    final /* synthetic */ C0066z f153a;

    C0065y(C0066z zVar) {
        this.f153a = zVar;
    }

    /* renamed from: b */
    public final void mo13b(Bundle bundle) throws RemoteException {
    }

    /* renamed from: c */
    public final void mo14c(Bundle bundle) throws RemoteException {
        int i = bundle.getInt("error.code", -100);
        if (i == -5) {
            Log.e("ARCore-InstallService", "The device is not supported.");
            this.f153a.f155b.mo341a(ArCoreApk.Availability.UNSUPPORTED_DEVICE_NOT_CAPABLE);
        } else if (i == -3) {
            Log.e("ARCore-InstallService", "The Google Play application must be updated.");
            this.f153a.f155b.mo341a(ArCoreApk.Availability.UNKNOWN_ERROR);
        } else if (i != 0) {
            StringBuilder sb = new StringBuilder(33);
            sb.append("requestInfo returned: ");
            sb.append(i);
            Log.e("ARCore-InstallService", sb.toString());
            this.f153a.f155b.mo341a(ArCoreApk.Availability.UNKNOWN_ERROR);
        } else {
            this.f153a.f155b.mo341a(ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED);
        }
    }
}
