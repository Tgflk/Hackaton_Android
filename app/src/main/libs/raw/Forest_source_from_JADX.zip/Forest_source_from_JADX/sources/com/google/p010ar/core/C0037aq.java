package com.google.p010ar.core;

import android.hardware.camera2.CameraCaptureSession;

/* renamed from: com.google.ar.core.aq */
final /* synthetic */ class C0037aq implements Runnable {

    /* renamed from: a */
    private final CameraCaptureSession.StateCallback f95a;

    /* renamed from: b */
    private final CameraCaptureSession f96b;

    C0037aq(CameraCaptureSession.StateCallback stateCallback, CameraCaptureSession cameraCaptureSession) {
        this.f95a = stateCallback;
        this.f96b = cameraCaptureSession;
    }

    public final void run() {
        CameraCaptureSession.StateCallback stateCallback = this.f95a;
        CameraCaptureSession cameraCaptureSession = this.f96b;
        int i = C0040at.f101d;
        stateCallback.onConfigureFailed(cameraCaptureSession);
    }
}
