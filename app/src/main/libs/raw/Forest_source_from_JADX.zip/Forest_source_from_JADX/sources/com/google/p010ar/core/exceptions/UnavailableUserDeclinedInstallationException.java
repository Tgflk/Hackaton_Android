package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException */
public class UnavailableUserDeclinedInstallationException extends UnavailableException {
    public UnavailableUserDeclinedInstallationException() {
    }

    public UnavailableUserDeclinedInstallationException(String str) {
        super(str);
    }
}
