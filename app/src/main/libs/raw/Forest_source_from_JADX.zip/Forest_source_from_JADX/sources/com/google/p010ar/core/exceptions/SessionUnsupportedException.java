package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.SessionUnsupportedException */
public class SessionUnsupportedException extends IllegalStateException {
    public SessionUnsupportedException() {
    }

    public SessionUnsupportedException(String str) {
        super(str);
    }
}
