package com.unity.p012xr.arcore;

/* renamed from: com.unity.xr.arcore.R */
public final class C0073R {
    private C0073R() {
    }
}
