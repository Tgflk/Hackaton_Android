package com.google.p010ar.core.exceptions;

import java.io.IOException;

/* renamed from: com.google.ar.core.exceptions.PlaybackFailedException */
public class PlaybackFailedException extends IOException {
    public PlaybackFailedException() {
    }

    public PlaybackFailedException(String str) {
        super(str);
    }
}
