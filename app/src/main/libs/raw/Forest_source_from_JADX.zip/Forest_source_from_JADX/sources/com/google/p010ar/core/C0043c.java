package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* 'enum' modifier removed */
/* renamed from: com.google.ar.core.c */
/* compiled from: ArCoreApk */
final class C0043c extends ArCoreApk.Availability {
    C0043c() {
        super("UNKNOWN_CHECKING", 1, 1, (C0020a) null);
    }

    public final boolean isTransient() {
        return true;
    }

    public final boolean isUnknown() {
        return true;
    }
}
