package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.CloudAnchorsNotConfiguredException */
public class CloudAnchorsNotConfiguredException extends IllegalStateException {
    public CloudAnchorsNotConfiguredException() {
    }

    public CloudAnchorsNotConfiguredException(String str) {
        super(str);
    }
}
