package com.unity3d.player;

import android.content.Context;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Handler;
import android.provider.Settings;

/* renamed from: com.unity3d.player.b */
final class C0124b {

    /* renamed from: a */
    private final Context f311a;

    /* renamed from: b */
    private final AudioManager f312b;

    /* renamed from: c */
    private C0125a f313c;

    /* renamed from: com.unity3d.player.b$a */
    private class C0125a extends ContentObserver {

        /* renamed from: b */
        private final C0126b f315b;

        /* renamed from: c */
        private final AudioManager f316c;

        /* renamed from: d */
        private final int f317d = 3;

        /* renamed from: e */
        private int f318e;

        public C0125a(Handler handler, AudioManager audioManager, int i, C0126b bVar) {
            super(handler);
            this.f316c = audioManager;
            this.f315b = bVar;
            this.f318e = audioManager.getStreamVolume(3);
        }

        public final boolean deliverSelfNotifications() {
            return super.deliverSelfNotifications();
        }

        public final void onChange(boolean z, Uri uri) {
            int streamVolume;
            AudioManager audioManager = this.f316c;
            if (audioManager != null && this.f315b != null && (streamVolume = audioManager.getStreamVolume(this.f317d)) != this.f318e) {
                this.f318e = streamVolume;
                this.f315b.onAudioVolumeChanged(streamVolume);
            }
        }
    }

    /* renamed from: com.unity3d.player.b$b */
    public interface C0126b {
        void onAudioVolumeChanged(int i);
    }

    public C0124b(Context context) {
        this.f311a = context;
        this.f312b = (AudioManager) context.getSystemService("audio");
    }

    /* renamed from: a */
    public final void mo563a() {
        if (this.f313c != null) {
            this.f311a.getContentResolver().unregisterContentObserver(this.f313c);
            this.f313c = null;
        }
    }

    /* renamed from: a */
    public final void mo564a(C0126b bVar) {
        this.f313c = new C0125a(new Handler(), this.f312b, 3, bVar);
        this.f311a.getContentResolver().registerContentObserver(Settings.System.CONTENT_URI, true, this.f313c);
    }
}
