package com.google.p010ar.core;

import android.hardware.camera2.CameraCaptureSession;

/* renamed from: com.google.ar.core.ap */
final /* synthetic */ class C0036ap implements Runnable {

    /* renamed from: a */
    private final CameraCaptureSession.StateCallback f93a;

    /* renamed from: b */
    private final CameraCaptureSession f94b;

    C0036ap(CameraCaptureSession.StateCallback stateCallback, CameraCaptureSession cameraCaptureSession) {
        this.f93a = stateCallback;
        this.f94b = cameraCaptureSession;
    }

    public final void run() {
        CameraCaptureSession.StateCallback stateCallback = this.f93a;
        CameraCaptureSession cameraCaptureSession = this.f94b;
        int i = C0040at.f101d;
        stateCallback.onConfigured(cameraCaptureSession);
    }
}
