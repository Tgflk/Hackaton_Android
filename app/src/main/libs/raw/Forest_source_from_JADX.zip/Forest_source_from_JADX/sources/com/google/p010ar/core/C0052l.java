package com.google.p010ar.core;

import com.google.p010ar.core.exceptions.FatalException;
import java.nio.ByteBuffer;
import p000a.p001a.C0000a;

/* renamed from: com.google.ar.core.l */
/* compiled from: ArImage */
final class C0052l extends C0000a {

    /* renamed from: a */
    final /* synthetic */ ArImage f122a;

    /* renamed from: b */
    private final long f123b;

    /* renamed from: c */
    private final int f124c;

    public C0052l(ArImage arImage, long j, int i) {
        this.f122a = arImage;
        this.f123b = j;
        this.f124c = i;
    }

    public final ByteBuffer getBuffer() {
        ArImage arImage = this.f122a;
        return arImage.nativeGetBuffer(arImage.session.nativeWrapperHandle, this.f123b, this.f124c).asReadOnlyBuffer();
    }

    public final int getPixelStride() {
        ArImage arImage = this.f122a;
        int access$200 = arImage.nativeGetPixelStride(arImage.session.nativeWrapperHandle, this.f123b, this.f124c);
        if (access$200 != -1) {
            return access$200;
        }
        throw new FatalException("Unknown error in ArImage.Plane.getPixelStride().");
    }

    public final int getRowStride() {
        ArImage arImage = this.f122a;
        int access$100 = arImage.nativeGetRowStride(arImage.session.nativeWrapperHandle, this.f123b, this.f124c);
        if (access$100 != -1) {
            return access$100;
        }
        throw new FatalException("Unknown error in ArImage.Plane.getRowStride().");
    }
}
