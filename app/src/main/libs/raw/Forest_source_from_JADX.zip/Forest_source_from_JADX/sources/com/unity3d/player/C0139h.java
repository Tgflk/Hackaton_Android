package com.unity3d.player;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;

/* renamed from: com.unity3d.player.h */
final class C0139h implements Application.ActivityLifecycleCallbacks {

    /* renamed from: a */
    WeakReference f367a = new WeakReference((Object) null);

    /* renamed from: b */
    Activity f368b;

    /* renamed from: c */
    View f369c = null;

    /* renamed from: com.unity3d.player.h$a */
    class C0140a extends View implements PixelCopy.OnPixelCopyFinishedListener {

        /* renamed from: a */
        Bitmap f370a;

        C0140a(Context context) {
            super(context);
        }

        /* renamed from: a */
        public final void mo600a(SurfaceView surfaceView) {
            Bitmap createBitmap = Bitmap.createBitmap(surfaceView.getWidth(), surfaceView.getHeight(), Bitmap.Config.ARGB_8888);
            this.f370a = createBitmap;
            PixelCopy.request(surfaceView, createBitmap, this, new Handler(Looper.getMainLooper()));
        }

        public final void onPixelCopyFinished(int i) {
            if (i == 0) {
                setBackground(new LayerDrawable(new Drawable[]{new ColorDrawable(-16777216), new BitmapDrawable(getResources(), this.f370a)}));
            }
        }
    }

    C0139h(Context context) {
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            this.f368b = activity;
            activity.getApplication().registerActivityLifecycleCallbacks(this);
        }
    }

    /* renamed from: a */
    public final void mo589a() {
        Activity activity = this.f368b;
        if (activity != null) {
            activity.getApplication().unregisterActivityLifecycleCallbacks(this);
        }
    }

    /* renamed from: a */
    public final void mo590a(SurfaceView surfaceView) {
        if (PlatformSupport.NOUGAT_SUPPORT && this.f367a.get() != this.f368b && this.f369c == null) {
            C0140a aVar = new C0140a(this.f368b);
            aVar.mo600a(surfaceView);
            this.f369c = aVar;
        }
    }

    /* renamed from: a */
    public final void mo591a(ViewGroup viewGroup) {
        View view = this.f369c;
        if (view != null && view.getParent() == null) {
            viewGroup.addView(this.f369c);
            viewGroup.bringChildToFront(this.f369c);
        }
    }

    /* renamed from: b */
    public final void mo592b(ViewGroup viewGroup) {
        View view = this.f369c;
        if (view != null && view.getParent() != null) {
            viewGroup.removeView(this.f369c);
        }
    }

    public final void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public final void onActivityDestroyed(Activity activity) {
    }

    public final void onActivityPaused(Activity activity) {
    }

    public final void onActivityResumed(Activity activity) {
        this.f367a = new WeakReference(activity);
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public final void onActivityStarted(Activity activity) {
    }

    public final void onActivityStopped(Activity activity) {
    }
}
