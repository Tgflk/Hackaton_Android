package com.google.p010ar.core;

/* renamed from: com.google.ar.core.o */
/* compiled from: ImageMetadata */
final class C0055o {

    /* renamed from: a */
    long f126a = 0;

    /* renamed from: b */
    int f127b = -1;

    /* renamed from: c */
    int f128c = -1;

    C0055o() {
    }
}
