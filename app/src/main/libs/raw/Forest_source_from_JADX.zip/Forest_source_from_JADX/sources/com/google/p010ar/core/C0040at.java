package com.google.p010ar.core;

import android.hardware.camera2.CameraCaptureSession;
import android.os.Handler;

/* renamed from: com.google.ar.core.at */
/* compiled from: SharedCamera */
final class C0040at extends CameraCaptureSession.StateCallback {

    /* renamed from: d */
    public static final /* synthetic */ int f101d = 0;

    /* renamed from: a */
    final /* synthetic */ Handler f102a;

    /* renamed from: b */
    final /* synthetic */ CameraCaptureSession.StateCallback f103b;

    /* renamed from: c */
    final /* synthetic */ SharedCamera f104c;

    C0040at(SharedCamera sharedCamera, Handler handler, CameraCaptureSession.StateCallback stateCallback) {
        this.f104c = sharedCamera;
        this.f102a = handler;
        this.f103b = stateCallback;
    }

    public final void onActive(CameraCaptureSession cameraCaptureSession) {
        this.f102a.post(new C0039as(this.f103b, cameraCaptureSession));
        this.f104c.onCaptureSessionActive(cameraCaptureSession);
    }

    public final void onClosed(CameraCaptureSession cameraCaptureSession) {
        this.f102a.post(new C0035ao(this.f103b, cameraCaptureSession));
        this.f104c.onCaptureSessionClosed(cameraCaptureSession);
    }

    public final void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
        this.f102a.post(new C0037aq(this.f103b, cameraCaptureSession));
        this.f104c.onCaptureSessionConfigureFailed(cameraCaptureSession);
    }

    public final void onConfigured(CameraCaptureSession cameraCaptureSession) {
        C0041au unused = this.f104c.sharedCameraInfo;
        this.f102a.post(new C0036ap(this.f103b, cameraCaptureSession));
        this.f104c.onCaptureSessionConfigured(cameraCaptureSession);
        if (this.f104c.sharedCameraInfo.mo334a() != null) {
            this.f104c.setDummyListenerToAvoidImageBufferStarvation();
        }
    }

    public final void onReady(CameraCaptureSession cameraCaptureSession) {
        this.f102a.post(new C0038ar(this.f103b, cameraCaptureSession));
        this.f104c.onCaptureSessionReady(cameraCaptureSession);
    }
}
