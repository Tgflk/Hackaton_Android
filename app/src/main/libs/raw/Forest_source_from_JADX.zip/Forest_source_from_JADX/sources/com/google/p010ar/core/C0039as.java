package com.google.p010ar.core;

import android.hardware.camera2.CameraCaptureSession;

/* renamed from: com.google.ar.core.as */
final /* synthetic */ class C0039as implements Runnable {

    /* renamed from: a */
    private final CameraCaptureSession.StateCallback f99a;

    /* renamed from: b */
    private final CameraCaptureSession f100b;

    C0039as(CameraCaptureSession.StateCallback stateCallback, CameraCaptureSession cameraCaptureSession) {
        this.f99a = stateCallback;
        this.f100b = cameraCaptureSession;
    }

    public final void run() {
        CameraCaptureSession.StateCallback stateCallback = this.f99a;
        CameraCaptureSession cameraCaptureSession = this.f100b;
        int i = C0040at.f101d;
        stateCallback.onActive(cameraCaptureSession);
    }
}
