package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.MetadataNotFoundException */
public class MetadataNotFoundException extends Exception {
    public MetadataNotFoundException() {
    }

    public MetadataNotFoundException(String str) {
        super(str);
    }
}
