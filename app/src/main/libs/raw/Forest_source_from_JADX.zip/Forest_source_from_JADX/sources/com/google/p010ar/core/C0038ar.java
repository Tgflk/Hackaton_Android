package com.google.p010ar.core;

import android.hardware.camera2.CameraCaptureSession;

/* renamed from: com.google.ar.core.ar */
final /* synthetic */ class C0038ar implements Runnable {

    /* renamed from: a */
    private final CameraCaptureSession.StateCallback f97a;

    /* renamed from: b */
    private final CameraCaptureSession f98b;

    C0038ar(CameraCaptureSession.StateCallback stateCallback, CameraCaptureSession cameraCaptureSession) {
        this.f97a = stateCallback;
        this.f98b = cameraCaptureSession;
    }

    public final void run() {
        CameraCaptureSession.StateCallback stateCallback = this.f97a;
        CameraCaptureSession cameraCaptureSession = this.f98b;
        int i = C0040at.f101d;
        stateCallback.onReady(cameraCaptureSession);
    }
}
