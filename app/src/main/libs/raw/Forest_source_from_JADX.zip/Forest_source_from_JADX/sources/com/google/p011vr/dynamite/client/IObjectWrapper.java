package com.google.p011vr.dynamite.client;

import android.os.IInterface;

/* renamed from: com.google.vr.dynamite.client.IObjectWrapper */
public interface IObjectWrapper extends IInterface {
}
