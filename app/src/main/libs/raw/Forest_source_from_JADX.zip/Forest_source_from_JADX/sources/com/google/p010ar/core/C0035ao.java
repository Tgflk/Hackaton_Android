package com.google.p010ar.core;

import android.hardware.camera2.CameraCaptureSession;

/* renamed from: com.google.ar.core.ao */
final /* synthetic */ class C0035ao implements Runnable {

    /* renamed from: a */
    private final CameraCaptureSession.StateCallback f91a;

    /* renamed from: b */
    private final CameraCaptureSession f92b;

    C0035ao(CameraCaptureSession.StateCallback stateCallback, CameraCaptureSession cameraCaptureSession) {
        this.f91a = stateCallback;
        this.f92b = cameraCaptureSession;
    }

    public final void run() {
        CameraCaptureSession.StateCallback stateCallback = this.f91a;
        CameraCaptureSession cameraCaptureSession = this.f92b;
        int i = C0040at.f101d;
        stateCallback.onClosed(cameraCaptureSession);
    }
}
