package com.google.p010ar.core;

import android.content.Context;
import android.os.RemoteException;
import android.util.Log;
import com.google.p010ar.core.ArCoreApk;

/* renamed from: com.google.ar.core.z */
/* compiled from: InstallServiceImpl */
final class C0066z implements Runnable {

    /* renamed from: a */
    final /* synthetic */ Context f154a;

    /* renamed from: b */
    final /* synthetic */ C0049i f155b;

    /* renamed from: c */
    final /* synthetic */ C0063w f156c;

    C0066z(C0063w wVar, Context context, C0049i iVar) {
        this.f156c = wVar;
        this.f154a = context;
        this.f155b = iVar;
    }

    public final void run() {
        try {
            this.f156c.f145c.mo12e(this.f154a.getApplicationInfo().packageName, C0063w.m70k(), new C0065y(this));
        } catch (RemoteException e) {
            Log.e("ARCore-InstallService", "requestInfo threw", e);
            this.f155b.mo341a(ArCoreApk.Availability.UNKNOWN_ERROR);
        }
    }
}
