package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.SessionNotPausedException */
public class SessionNotPausedException extends IllegalStateException {
    public SessionNotPausedException() {
    }

    public SessionNotPausedException(String str) {
        super(str);
    }
}
