package com.google.p010ar.core;

import android.hardware.camera2.CameraDevice;

/* renamed from: com.google.ar.core.ak */
final /* synthetic */ class C0031ak implements Runnable {

    /* renamed from: a */
    private final CameraDevice.StateCallback f80a;

    /* renamed from: b */
    private final CameraDevice f81b;

    C0031ak(CameraDevice.StateCallback stateCallback, CameraDevice cameraDevice) {
        this.f80a = stateCallback;
        this.f81b = cameraDevice;
    }

    public final void run() {
        CameraDevice.StateCallback stateCallback = this.f80a;
        CameraDevice cameraDevice = this.f81b;
        int i = C0034an.f87d;
        stateCallback.onOpened(cameraDevice);
    }
}
