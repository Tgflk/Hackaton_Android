package com.google.p010ar.core;

import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraDevice;
import android.view.Surface;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: com.google.ar.core.au */
/* compiled from: SharedCamera */
final class C0041au {

    /* renamed from: a */
    private CameraDevice f105a = null;

    /* renamed from: b */
    private final Map<String, List<Surface>> f106b = new HashMap();

    /* renamed from: c */
    private SurfaceTexture f107c = null;

    /* renamed from: d */
    private Surface f108d = null;

    private C0041au() {
    }

    /* synthetic */ C0041au(byte[] bArr) {
    }

    /* renamed from: a */
    public final CameraDevice mo334a() {
        return this.f105a;
    }

    /* renamed from: b */
    public final void mo335b(CameraDevice cameraDevice) {
        this.f105a = cameraDevice;
    }

    /* renamed from: c */
    public final void mo336c(String str, List<Surface> list) {
        this.f106b.put(str, list);
    }

    /* renamed from: d */
    public final SurfaceTexture mo337d() {
        return this.f107c;
    }

    /* renamed from: e */
    public final void mo338e(SurfaceTexture surfaceTexture) {
        this.f107c = surfaceTexture;
    }

    /* renamed from: f */
    public final Surface mo339f() {
        return this.f108d;
    }

    /* renamed from: g */
    public final void mo340g(Surface surface) {
        this.f108d = surface;
    }
}
