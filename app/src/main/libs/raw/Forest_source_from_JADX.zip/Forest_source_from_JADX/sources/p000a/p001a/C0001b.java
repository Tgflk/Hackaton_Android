package p000a.p001a;

import android.media.Image;

/* renamed from: a.a.b */
/* compiled from: VisibleImage */
public abstract class C0001b extends Image {
}
