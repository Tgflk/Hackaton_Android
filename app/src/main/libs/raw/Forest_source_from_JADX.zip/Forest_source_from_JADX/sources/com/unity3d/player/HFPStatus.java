package com.unity3d.player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;

public class HFPStatus {

    /* renamed from: a */
    private Context f168a;

    /* renamed from: b */
    private BroadcastReceiver f169b = null;

    /* renamed from: c */
    private Intent f170c = null;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public boolean f171d = false;
    /* access modifiers changed from: private */

    /* renamed from: e */
    public AudioManager f172e = null;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public int f173f = C0076a.f175a;

    /* renamed from: com.unity3d.player.HFPStatus$a */
    enum C0076a {
        ;

        static {
            f178d = new int[]{1, 2, 3};
        }
    }

    public HFPStatus(Context context) {
        this.f168a = context;
        this.f172e = (AudioManager) context.getSystemService("audio");
        initHFPStatusJni();
    }

    private final native void deinitHFPStatusJni();

    private final native void initHFPStatusJni();

    /* renamed from: a */
    public final void mo395a() {
        deinitHFPStatusJni();
    }

    /* access modifiers changed from: protected */
    public boolean getHFPStat() {
        return this.f173f == C0076a.f176b;
    }

    /* access modifiers changed from: protected */
    public void requestHFPStat() {
        C00751 r0 = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                int intExtra = intent.getIntExtra("android.media.extra.SCO_AUDIO_STATE", -1);
                if (intExtra == 0) {
                    if (HFPStatus.this.f171d) {
                        HFPStatus.this.f172e.setMode(0);
                    }
                    boolean unused = HFPStatus.this.f171d = false;
                } else if (intExtra == 1) {
                    int unused2 = HFPStatus.this.f173f = C0076a.f176b;
                    if (!HFPStatus.this.f171d) {
                        HFPStatus.this.f172e.stopBluetoothSco();
                    } else {
                        HFPStatus.this.f172e.setMode(3);
                    }
                } else if (intExtra == 2) {
                    if (HFPStatus.this.f173f == C0076a.f176b) {
                        boolean unused3 = HFPStatus.this.f171d = true;
                    } else {
                        int unused4 = HFPStatus.this.f173f = C0076a.f177c;
                    }
                }
            }
        };
        this.f169b = r0;
        this.f170c = this.f168a.registerReceiver(r0, new IntentFilter("android.media.ACTION_SCO_AUDIO_STATE_UPDATED"));
        try {
            this.f172e.startBluetoothSco();
        } catch (NullPointerException unused) {
            C0136f.Log(5, "startBluetoothSco() failed. no bluetooth device connected.");
        }
    }
}
