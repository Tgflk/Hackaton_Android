package com.google.p010ar.core;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

/* renamed from: com.google.ar.core.x */
/* compiled from: InstallServiceImpl */
final class C0064x implements ServiceConnection {

    /* renamed from: a */
    final /* synthetic */ C0063w f152a;

    C0064x(C0063w wVar) {
        this.f152a = wVar;
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.f152a.m71l(iBinder);
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        this.f152a.m72m();
    }
}
