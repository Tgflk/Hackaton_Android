package com.google.p004a.p005a;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: com.google.a.a.a */
/* compiled from: BaseProxy */
public class C0006a implements IInterface {

    /* renamed from: a */
    private final IBinder f3a;

    /* renamed from: b */
    private final String f4b;

    protected C0006a(IBinder iBinder, String str) {
        this.f3a = iBinder;
        this.f4b = str;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final Parcel mo4a() {
        Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.f4b);
        return obtain;
    }

    public final IBinder asBinder() {
        return this.f3a;
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public final Parcel mo6b(int i, Parcel parcel) throws RemoteException {
        parcel = Parcel.obtain();
        try {
            this.f3a.transact(i, parcel, parcel, 0);
            parcel.readException();
            return parcel;
        } catch (RuntimeException e) {
            throw e;
        } finally {
            parcel.recycle();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public final void mo7c(int i, Parcel parcel) throws RemoteException {
        try {
            this.f3a.transact(i, parcel, (Parcel) null, 1);
        } finally {
            parcel.recycle();
        }
    }
}
