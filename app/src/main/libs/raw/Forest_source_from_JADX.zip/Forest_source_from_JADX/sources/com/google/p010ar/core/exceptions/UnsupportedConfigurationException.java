package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.UnsupportedConfigurationException */
public class UnsupportedConfigurationException extends RuntimeException {
    public UnsupportedConfigurationException() {
    }

    public UnsupportedConfigurationException(String str) {
        super(str);
    }
}
