package com.unity3d.player;

import android.app.Activity;

/* renamed from: com.unity3d.player.d */
interface C0134d {
    /* renamed from: a */
    Object mo547a(IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback);

    /* renamed from: a */
    String mo548a(String str);

    /* renamed from: a */
    void mo549a(Activity activity, IAssetPackManagerMobileDataConfirmationCallback iAssetPackManagerMobileDataConfirmationCallback);

    /* renamed from: a */
    void mo550a(Object obj);

    /* renamed from: a */
    void mo551a(String[] strArr);

    /* renamed from: a */
    void mo552a(String[] strArr, IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback);

    /* renamed from: a */
    void mo553a(String[] strArr, IAssetPackManagerStatusQueryCallback iAssetPackManagerStatusQueryCallback);

    /* renamed from: b */
    void mo554b(String str);
}
