package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.UnavailableArcoreNotInstalledException */
public class UnavailableArcoreNotInstalledException extends UnavailableException {
    public UnavailableArcoreNotInstalledException() {
    }

    public UnavailableArcoreNotInstalledException(String str) {
        super(str);
    }
}
