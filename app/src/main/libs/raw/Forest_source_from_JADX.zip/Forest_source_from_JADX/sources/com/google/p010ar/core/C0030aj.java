package com.google.p010ar.core;

import android.hardware.camera2.CameraDevice;

/* renamed from: com.google.ar.core.aj */
final /* synthetic */ class C0030aj implements Runnable {

    /* renamed from: a */
    private final CameraDevice.StateCallback f78a;

    /* renamed from: b */
    private final CameraDevice f79b;

    C0030aj(CameraDevice.StateCallback stateCallback, CameraDevice cameraDevice) {
        this.f78a = stateCallback;
        this.f79b = cameraDevice;
    }

    public final void run() {
        CameraDevice.StateCallback stateCallback = this.f78a;
        CameraDevice cameraDevice = this.f79b;
        int i = C0034an.f87d;
        stateCallback.onClosed(cameraDevice);
    }
}
