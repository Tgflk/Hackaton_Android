package com.google.p010ar.core;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.content.pm.PackageInstaller;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import com.google.p004a.p006b.p007a.p008a.p009a.C0010b;
import com.google.p004a.p006b.p007a.p008a.p009a.C0011c;
import com.google.p010ar.core.ArCoreApk;
import com.google.p010ar.core.exceptions.FatalException;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Queue;

/* renamed from: com.google.ar.core.w */
/* compiled from: InstallService */
final class C0063w {

    /* renamed from: a */
    private final Queue f143a;

    /* renamed from: b */
    private Context f144b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public C0011c f145c;

    /* renamed from: d */
    private final ServiceConnection f146d;

    /* renamed from: e */
    private BroadcastReceiver f147e;

    /* renamed from: f */
    private Context f148f;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public PackageInstaller f149g;

    /* renamed from: h */
    private PackageInstaller.SessionCallback f150h;

    /* renamed from: i */
    private volatile int f151i;

    C0063w() {
    }

    C0063w(byte[] bArr) {
        this();
        this.f143a = new ArrayDeque();
        this.f151i = 1;
        this.f146d = new C0064x(this);
    }

    /* renamed from: k */
    static /* synthetic */ Bundle m70k() {
        Bundle bundle = new Bundle();
        bundle.putCharSequence("package.name", "com.google.ar.core");
        return bundle;
    }

    /* access modifiers changed from: private */
    /* renamed from: l */
    public synchronized void m71l(IBinder iBinder) {
        C0011c b = C0010b.m11b(iBinder);
        Log.i("ARCore-InstallService", "Install service connected");
        this.f145c = b;
        this.f151i = 3;
        for (Runnable run : this.f143a) {
            run.run();
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: m */
    public synchronized void m72m() {
        Log.i("ARCore-InstallService", "Install service disconnected");
        this.f151i = 1;
        this.f145c = null;
    }

    /* access modifiers changed from: private */
    /* renamed from: o */
    public static void m74o(Activity activity, C0061u uVar) {
        boolean z;
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.google.ar.core"));
            C0051k a = C0051k.m49a();
            Iterator<ResolveInfo> it = activity.getPackageManager().queryIntentActivities(intent, ImageMetadata.CONTROL_AE_ANTIBANDING_MODE).iterator();
            while (true) {
                if (!it.hasNext()) {
                    z = false;
                    break;
                }
                ResolveInfo next = it.next();
                if (next.activityInfo != null && next.activityInfo.name.equals("com.sec.android.app.samsungapps.MainForChina")) {
                    z = true;
                    break;
                }
            }
            a.f112b = !z;
            activity.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            uVar.mo355b(new FatalException("Failed to launch installer.", e));
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: p */
    public static void m75p(Activity activity, Bundle bundle, C0061u uVar) {
        PendingIntent pendingIntent = (PendingIntent) bundle.getParcelable("resolution.intent");
        if (pendingIntent != null) {
            try {
                activity.startIntentSenderForResult(pendingIntent.getIntentSender(), 1234, new Intent(activity, activity.getClass()), 0, 0, 0);
            } catch (IntentSender.SendIntentException e) {
                uVar.mo355b(new FatalException("Installation Intent failed", e));
            }
        } else {
            Log.e("ARCore-InstallService", "Did not get pending intent.");
            uVar.mo355b(new FatalException("Installation intent failed to unparcel."));
        }
    }

    /* renamed from: a */
    public synchronized void mo356a(Context context) {
        this.f144b = context;
        if (context.bindService(new Intent("com.google.android.play.core.install.BIND_INSTALL_SERVICE").setPackage("com.android.vending"), this.f146d, 1)) {
            this.f151i = 2;
            return;
        }
        this.f151i = 1;
        this.f144b = null;
        Log.w("ARCore-InstallService", "bindService returned false.");
        context.unbindService(this.f146d);
    }

    /* renamed from: b */
    public synchronized void mo357b() {
        int i = this.f151i;
        int i2 = i - 1;
        if (i != 0) {
            if (i2 == 1 || i2 == 2) {
                this.f144b.unbindService(this.f146d);
                this.f144b = null;
                this.f151i = 1;
            }
            BroadcastReceiver broadcastReceiver = this.f147e;
            if (broadcastReceiver != null) {
                this.f148f.unregisterReceiver(broadcastReceiver);
            }
            PackageInstaller.SessionCallback sessionCallback = this.f150h;
            if (sessionCallback != null) {
                this.f149g.unregisterSessionCallback(sessionCallback);
                this.f150h = null;
                return;
            }
            return;
        }
        throw null;
    }

    /* renamed from: c */
    public synchronized void mo358c(Context context, C0049i iVar) {
        try {
            m73n(new C0066z(this, context, iVar));
        } catch (C0026af unused) {
            Log.e("ARCore-InstallService", "Play Store install service could not be bound.");
            iVar.mo341a(ArCoreApk.Availability.UNKNOWN_ERROR);
        }
    }

    /* renamed from: d */
    public void mo359d(Activity activity, C0061u uVar) {
        if (this.f150h == null) {
            this.f149g = activity.getPackageManager().getPackageInstaller();
            C0021aa aaVar = new C0021aa(this, uVar);
            this.f150h = aaVar;
            this.f149g.registerSessionCallback(aaVar);
        }
        if (this.f147e == null) {
            C0022ab abVar = new C0022ab(uVar);
            this.f147e = abVar;
            this.f148f = activity;
            activity.registerReceiver(abVar, new IntentFilter("com.google.android.play.core.install.ACTION_INSTALL_STATUS"));
        }
        try {
            m73n(new C0025ae(this, activity, uVar));
        } catch (C0026af unused) {
            Log.w("ARCore-InstallService", "requestInstall bind failed, launching fullscreen.");
            m74o(activity, uVar);
        }
    }

    /* renamed from: n */
    private synchronized void m73n(Runnable runnable) throws C0026af {
        int i = this.f151i;
        int i2 = i - 1;
        if (i == 0) {
            throw null;
        } else if (i2 == 0) {
            throw new C0026af();
        } else if (i2 == 1) {
            this.f143a.offer(runnable);
        } else if (i2 == 2) {
            runnable.run();
        }
    }
}
