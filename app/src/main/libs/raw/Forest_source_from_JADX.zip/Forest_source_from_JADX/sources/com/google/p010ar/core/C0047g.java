package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* 'enum' modifier removed */
/* renamed from: com.google.ar.core.g */
/* compiled from: ArCoreApk */
final class C0047g extends ArCoreApk.Availability {
    C0047g() {
        super("SUPPORTED_APK_TOO_OLD", 5, 202, (C0020a) null);
    }

    public final boolean isSupported() {
        return true;
    }
}
