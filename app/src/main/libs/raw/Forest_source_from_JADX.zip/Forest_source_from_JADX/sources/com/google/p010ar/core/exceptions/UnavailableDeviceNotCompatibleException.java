package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException */
public class UnavailableDeviceNotCompatibleException extends UnavailableException {
    public UnavailableDeviceNotCompatibleException() {
    }

    public UnavailableDeviceNotCompatibleException(String str) {
        super(str);
    }
}
