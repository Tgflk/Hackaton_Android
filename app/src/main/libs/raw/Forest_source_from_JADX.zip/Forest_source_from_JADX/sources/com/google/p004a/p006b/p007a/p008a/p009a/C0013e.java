package com.google.p004a.p006b.p007a.p008a.p009a;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;

/* renamed from: com.google.a.b.a.a.a.e */
/* compiled from: IInstallServiceCallback */
public interface C0013e extends IInterface {
    /* renamed from: b */
    void mo13b(Bundle bundle) throws RemoteException;

    /* renamed from: c */
    void mo14c(Bundle bundle) throws RemoteException;
}
