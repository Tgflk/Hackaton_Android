package com.google.p004a.p006b.p007a.p008a.p009a;

import android.os.Bundle;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.p004a.p005a.C0007b;
import com.google.p004a.p005a.C0008c;

/* renamed from: com.google.a.b.a.a.a.d */
/* compiled from: IInstallServiceCallback */
public abstract class C0012d extends C0007b implements C0013e {
    public C0012d() {
        super("com.google.android.play.core.install.protocol.IInstallServiceCallback");
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final boolean mo8a(int i, Parcel parcel) throws RemoteException {
        if (i == 1) {
            mo13b((Bundle) C0008c.m6a(parcel, Bundle.CREATOR));
        } else if (i == 2) {
            mo14c((Bundle) C0008c.m6a(parcel, Bundle.CREATOR));
        } else if (i != 3) {
            return false;
        } else {
            Bundle bundle = (Bundle) C0008c.m6a(parcel, Bundle.CREATOR);
        }
        return true;
    }
}
