package com.google.p004a.p006b.p007a.p008a.p009a;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;
import java.util.List;

/* renamed from: com.google.a.b.a.a.a.c */
/* compiled from: IInstallService */
public interface C0011c extends IInterface {
    /* renamed from: d */
    void mo11d(String str, List<Bundle> list, Bundle bundle, C0013e eVar) throws RemoteException;

    /* renamed from: e */
    void mo12e(String str, Bundle bundle, C0013e eVar) throws RemoteException;
}
