package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* 'enum' modifier removed */
/* renamed from: com.google.ar.core.h */
/* compiled from: ArCoreApk */
final class C0048h extends ArCoreApk.Availability {
    C0048h() {
        super("SUPPORTED_INSTALLED", 6, 203, (C0020a) null);
    }

    public final boolean isSupported() {
        return true;
    }
}
