package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.DataInvalidFormatException */
public class DataInvalidFormatException extends IllegalArgumentException {
    public DataInvalidFormatException() {
    }

    public DataInvalidFormatException(String str) {
        super(str);
    }
}
