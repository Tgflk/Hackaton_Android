package com.google.p011vr.dynamite.client;

import com.google.p004a.p005a.C0007b;

/* renamed from: com.google.vr.dynamite.client.c */
/* compiled from: IObjectWrapper */
public class C0069c extends C0007b implements IObjectWrapper {
    public C0069c() {
        super("com.google.vr.dynamite.client.IObjectWrapper");
    }
}
