package com.unity3d.player;

import android.app.Activity;
import android.content.Context;

class PlayAssetDeliveryUnityWrapper {

    /* renamed from: a */
    private static PlayAssetDeliveryUnityWrapper f186a;

    /* renamed from: b */
    private C0134d f187b;

    private PlayAssetDeliveryUnityWrapper(Context context) {
        if (f186a == null) {
            try {
                Class.forName("com.google.android.play.core.assetpacks.AssetPackManager");
                this.f187b = m101a(context);
            } catch (ClassNotFoundException unused) {
                this.f187b = null;
            }
        } else {
            throw new RuntimeException("PlayAssetDeliveryUnityWrapper should be created only once. Use getInstance() instead.");
        }
    }

    /* renamed from: a */
    private static C0134d m101a(Context context) {
        return C0116a.m135a(context);
    }

    /* renamed from: a */
    private void m102a() {
        if (playCoreApiMissing()) {
            throw new RuntimeException("AssetPackManager API is not available! Make sure your gradle project includes \"com.google.android.play:core\" dependency.");
        }
    }

    public static synchronized PlayAssetDeliveryUnityWrapper getInstance() {
        PlayAssetDeliveryUnityWrapper playAssetDeliveryUnityWrapper;
        Class<PlayAssetDeliveryUnityWrapper> cls = PlayAssetDeliveryUnityWrapper.class;
        synchronized (cls) {
            while (f186a == null) {
                try {
                    cls.wait(3000);
                } catch (InterruptedException e) {
                    C0136f.Log(6, e.getMessage());
                }
            }
            if (f186a != null) {
                playAssetDeliveryUnityWrapper = f186a;
            } else {
                throw new RuntimeException("PlayAssetDeliveryUnityWrapper is not yet initialised.");
            }
        }
        return playAssetDeliveryUnityWrapper;
    }

    public static synchronized PlayAssetDeliveryUnityWrapper init(Context context) {
        PlayAssetDeliveryUnityWrapper playAssetDeliveryUnityWrapper;
        Class<PlayAssetDeliveryUnityWrapper> cls = PlayAssetDeliveryUnityWrapper.class;
        synchronized (cls) {
            if (f186a == null) {
                f186a = new PlayAssetDeliveryUnityWrapper(context);
                cls.notifyAll();
                playAssetDeliveryUnityWrapper = f186a;
            } else {
                throw new RuntimeException("PlayAssetDeliveryUnityWrapper.init() should be called only once. Use getInstance() instead.");
            }
        }
        return playAssetDeliveryUnityWrapper;
    }

    public void cancelAssetPackDownload(String str) {
        cancelAssetPackDownloads(new String[]{str});
    }

    public void cancelAssetPackDownloads(String[] strArr) {
        m102a();
        this.f187b.mo551a(strArr);
    }

    public void downloadAssetPack(String str, IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback) {
        downloadAssetPacks(new String[]{str}, iAssetPackManagerDownloadStatusCallback);
    }

    public void downloadAssetPacks(String[] strArr, IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback) {
        m102a();
        this.f187b.mo552a(strArr, iAssetPackManagerDownloadStatusCallback);
    }

    public String getAssetPackPath(String str) {
        m102a();
        return this.f187b.mo548a(str);
    }

    public void getAssetPackState(String str, IAssetPackManagerStatusQueryCallback iAssetPackManagerStatusQueryCallback) {
        getAssetPackStates(new String[]{str}, iAssetPackManagerStatusQueryCallback);
    }

    public void getAssetPackStates(String[] strArr, IAssetPackManagerStatusQueryCallback iAssetPackManagerStatusQueryCallback) {
        m102a();
        this.f187b.mo553a(strArr, iAssetPackManagerStatusQueryCallback);
    }

    public boolean playCoreApiMissing() {
        return this.f187b == null;
    }

    public Object registerDownloadStatusListener(IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback) {
        m102a();
        return this.f187b.mo547a(iAssetPackManagerDownloadStatusCallback);
    }

    public void removeAssetPack(String str) {
        m102a();
        this.f187b.mo554b(str);
    }

    public void requestToUseMobileData(Activity activity, IAssetPackManagerMobileDataConfirmationCallback iAssetPackManagerMobileDataConfirmationCallback) {
        m102a();
        this.f187b.mo549a(activity, iAssetPackManagerMobileDataConfirmationCallback);
    }

    public void unregisterDownloadStatusListener(Object obj) {
        m102a();
        this.f187b.mo550a(obj);
    }
}
