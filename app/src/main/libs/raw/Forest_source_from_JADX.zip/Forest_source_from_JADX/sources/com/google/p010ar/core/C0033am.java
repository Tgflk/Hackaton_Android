package com.google.p010ar.core;

import android.hardware.camera2.CameraDevice;

/* renamed from: com.google.ar.core.am */
final /* synthetic */ class C0033am implements Runnable {

    /* renamed from: a */
    private final CameraDevice.StateCallback f84a;

    /* renamed from: b */
    private final CameraDevice f85b;

    /* renamed from: c */
    private final int f86c;

    C0033am(CameraDevice.StateCallback stateCallback, CameraDevice cameraDevice, int i) {
        this.f84a = stateCallback;
        this.f85b = cameraDevice;
        this.f86c = i;
    }

    public final void run() {
        CameraDevice.StateCallback stateCallback = this.f84a;
        CameraDevice cameraDevice = this.f85b;
        int i = this.f86c;
        int i2 = C0034an.f87d;
        stateCallback.onError(cameraDevice, i);
    }
}
