package com.google.p010ar.core;

/* renamed from: com.google.ar.core.v */
/* compiled from: InstallService */
enum C0062v {
    ACCEPTED,
    CANCELLED,
    COMPLETED
}
