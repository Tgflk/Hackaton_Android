package com.unity3d.player;

/* renamed from: com.unity3d.player.l */
final class C0150l {

    /* renamed from: a */
    private static boolean f393a = false;

    /* renamed from: b */
    private boolean f394b = false;

    /* renamed from: c */
    private boolean f395c = false;

    /* renamed from: d */
    private boolean f396d = true;

    /* renamed from: e */
    private boolean f397e = false;

    C0150l() {
    }

    /* renamed from: a */
    static void m228a() {
        f393a = true;
    }

    /* renamed from: b */
    static void m229b() {
        f393a = false;
    }

    /* renamed from: c */
    static boolean m230c() {
        return f393a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public final void mo624a(boolean z) {
        this.f394b = z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public final void mo625b(boolean z) {
        this.f396d = z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public final void mo626c(boolean z) {
        this.f397e = z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public final void mo627d(boolean z) {
        this.f395c = z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public final boolean mo628d() {
        return this.f396d;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public final boolean mo629e() {
        return this.f397e;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public final boolean mo630e(boolean z) {
        if (f393a) {
            return (z || this.f394b) && !this.f396d && !this.f395c;
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public final boolean mo631f() {
        return this.f395c;
    }

    public final String toString() {
        return super.toString();
    }
}
