package com.google.p010ar.core;

/* renamed from: com.google.ar.core.R */
public final class C0018R {

    /* renamed from: com.google.ar.core.R$id */
    public static final class C0019id {
        public static final int __arcore_cancelButton = 2130771968;
        public static final int __arcore_continueButton = 2130771969;
        public static final int __arcore_messageText = 2130771970;

        private C0019id() {
        }
    }

    /* renamed from: com.google.ar.core.R$layout */
    public static final class layout {
        public static final int __arcore_education = 2130837504;

        private layout() {
        }
    }

    /* renamed from: com.google.ar.core.R$raw */
    public static final class raw {
        public static final int keep_arcore = 2130968576;

        private raw() {
        }
    }

    /* renamed from: com.google.ar.core.R$string */
    public static final class string {
        public static final int __arcore_cancel = 2131034112;
        public static final int __arcore_continue = 2131034113;
        public static final int __arcore_install_app = 2131034114;
        public static final int __arcore_install_feature = 2131034115;
        public static final int __arcore_installing = 2131034116;

        private string() {
        }
    }

    private C0018R() {
    }
}
