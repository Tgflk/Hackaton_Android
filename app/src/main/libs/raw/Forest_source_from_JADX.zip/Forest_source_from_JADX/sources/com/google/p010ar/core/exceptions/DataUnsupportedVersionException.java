package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.DataUnsupportedVersionException */
public class DataUnsupportedVersionException extends IllegalArgumentException {
    public DataUnsupportedVersionException() {
    }

    public DataUnsupportedVersionException(String str) {
        super(str);
    }
}
