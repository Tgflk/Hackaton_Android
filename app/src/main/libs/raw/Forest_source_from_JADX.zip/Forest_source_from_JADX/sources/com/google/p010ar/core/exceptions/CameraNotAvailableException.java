package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.CameraNotAvailableException */
public class CameraNotAvailableException extends Exception {
    public CameraNotAvailableException() {
    }

    public CameraNotAvailableException(String str) {
        super(str);
    }
}
