package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* renamed from: com.google.ar.core.j */
/* compiled from: ArCoreApkImpl */
final class C0050j implements C0049i {

    /* renamed from: a */
    final /* synthetic */ C0051k f109a;

    C0050j(C0051k kVar) {
        this.f109a = kVar;
    }

    /* renamed from: a */
    public final void mo341a(ArCoreApk.Availability availability) {
        synchronized (this.f109a) {
            this.f109a.f116g = availability;
            this.f109a.f117h = false;
        }
    }
}
