package com.google.p010ar.core;

import com.google.p010ar.core.ArCoreApk;

/* renamed from: com.google.ar.core.i */
/* compiled from: ArCoreApk */
interface C0049i {
    /* renamed from: a */
    void mo341a(ArCoreApk.Availability availability);
}
