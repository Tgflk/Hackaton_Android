package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.UnavailableApkTooOldException */
public class UnavailableApkTooOldException extends UnavailableException {
    public UnavailableApkTooOldException() {
    }

    public UnavailableApkTooOldException(String str) {
        super(str);
    }
}
