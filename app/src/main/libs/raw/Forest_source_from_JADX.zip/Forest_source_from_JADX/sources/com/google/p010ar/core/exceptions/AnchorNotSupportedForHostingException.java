package com.google.p010ar.core.exceptions;

/* renamed from: com.google.ar.core.exceptions.AnchorNotSupportedForHostingException */
public class AnchorNotSupportedForHostingException extends UnsupportedOperationException {
    public AnchorNotSupportedForHostingException() {
    }

    public AnchorNotSupportedForHostingException(String str) {
        super(str);
    }
}
