package com.unity3d.player;

import android.app.Activity;
import android.content.Context;
import com.unity3d.player.C0151m;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/* renamed from: com.unity3d.player.n */
final class C0154n {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public UnityPlayer f427a = null;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public Context f428b = null;

    /* renamed from: c */
    private C0161a f429c;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public final Semaphore f430d = new Semaphore(0);
    /* access modifiers changed from: private */

    /* renamed from: e */
    public final Lock f431e = new ReentrantLock();
    /* access modifiers changed from: private */

    /* renamed from: f */
    public C0151m f432f = null;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public int f433g = 2;

    /* renamed from: h */
    private boolean f434h = false;
    /* access modifiers changed from: private */

    /* renamed from: i */
    public boolean f435i = false;

    /* renamed from: com.unity3d.player.n$a */
    public interface C0161a {
        /* renamed from: a */
        void mo491a();
    }

    C0154n(UnityPlayer unityPlayer) {
        this.f427a = unityPlayer;
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public void m254d() {
        C0151m mVar = this.f432f;
        if (mVar != null) {
            this.f427a.removeViewFromPlayer(mVar);
            this.f435i = false;
            this.f432f.destroyPlayer();
            this.f432f = null;
            C0161a aVar = this.f429c;
            if (aVar != null) {
                aVar.mo491a();
            }
        }
    }

    /* renamed from: a */
    public final void mo661a() {
        this.f431e.lock();
        C0151m mVar = this.f432f;
        if (mVar != null) {
            if (this.f433g == 0) {
                mVar.CancelOnPrepare();
            } else if (this.f435i) {
                boolean a = mVar.mo634a();
                this.f434h = a;
                if (!a) {
                    this.f432f.pause();
                }
            }
        }
        this.f431e.unlock();
    }

    /* renamed from: a */
    public final boolean mo662a(Context context, String str, int i, int i2, int i3, boolean z, long j, long j2, C0161a aVar) {
        this.f431e.lock();
        this.f429c = aVar;
        this.f428b = context;
        this.f430d.drainPermits();
        this.f433g = 2;
        final String str2 = str;
        final int i4 = i;
        final int i5 = i2;
        final int i6 = i3;
        final boolean z2 = z;
        final long j3 = j;
        final long j4 = j2;
        runOnUiThread(new Runnable() {
            public final void run() {
                if (C0154n.this.f432f != null) {
                    C0136f.Log(5, "Video already playing");
                    int unused = C0154n.this.f433g = 2;
                    C0154n.this.f430d.release();
                    return;
                }
                C0151m unused2 = C0154n.this.f432f = new C0151m(C0154n.this.f428b, str2, i4, i5, i6, z2, j3, j4, new C0151m.C0152a() {
                    /* renamed from: a */
                    public final void mo658a(int i) {
                        C0154n.this.f431e.lock();
                        int unused = C0154n.this.f433g = i;
                        if (i == 3 && C0154n.this.f435i) {
                            C0154n.this.runOnUiThread(new Runnable() {
                                public final void run() {
                                    C0154n.this.m254d();
                                    C0154n.this.f427a.resume();
                                }
                            });
                        }
                        if (i != 0) {
                            C0154n.this.f430d.release();
                        }
                        C0154n.this.f431e.unlock();
                    }
                });
                if (C0154n.this.f432f != null) {
                    C0154n.this.f427a.addView(C0154n.this.f432f);
                }
            }
        });
        boolean z3 = false;
        try {
            this.f431e.unlock();
            this.f430d.acquire();
            this.f431e.lock();
            if (this.f433g != 2) {
                z3 = true;
            }
        } catch (InterruptedException unused) {
        }
        runOnUiThread(new Runnable() {
            public final void run() {
                C0154n.this.f427a.pause();
            }
        });
        runOnUiThread((!z3 || this.f433g == 3) ? new Runnable() {
            public final void run() {
                C0154n.this.m254d();
                C0154n.this.f427a.resume();
            }
        } : new Runnable() {
            public final void run() {
                if (C0154n.this.f432f != null) {
                    C0154n.this.f427a.addViewToPlayer(C0154n.this.f432f, true);
                    boolean unused = C0154n.this.f435i = true;
                    C0154n.this.f432f.requestFocus();
                }
            }
        });
        this.f431e.unlock();
        return z3;
    }

    /* renamed from: b */
    public final void mo663b() {
        this.f431e.lock();
        C0151m mVar = this.f432f;
        if (mVar != null && this.f435i && !this.f434h) {
            mVar.start();
        }
        this.f431e.unlock();
    }

    /* renamed from: c */
    public final void mo664c() {
        this.f431e.lock();
        C0151m mVar = this.f432f;
        if (mVar != null) {
            mVar.updateVideoLayout();
        }
        this.f431e.unlock();
    }

    /* access modifiers changed from: protected */
    public final void runOnUiThread(Runnable runnable) {
        Context context = this.f428b;
        if (context instanceof Activity) {
            ((Activity) context).runOnUiThread(runnable);
        } else {
            C0136f.Log(5, "Not running from an Activity; Ignoring execution request...");
        }
    }
}
